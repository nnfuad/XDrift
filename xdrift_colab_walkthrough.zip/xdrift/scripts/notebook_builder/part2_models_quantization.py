"""Part 2: Models and Quantization (Sections 4, 5, 6, 7) for XDrift Master Notebook."""

from .helpers import add_markdown, add_code

def build_part2(cells):
    # =========================================================================
    # SECTION 4: Flow Construction and Feature Engineering
    # =========================================================================
    add_markdown(cells, r"""
---
## Section 4: Flow Construction and Feature Engineering

### What We Are Investigating
Raw network traffic consists of variable-length packet captures containing arbitrary protocol headers and encrypted payload bytes. We investigate how raw packets are converted into fixed-size, standardized numerical tensors suitable for deep learning, while preserving temporal dynamics and directional flow structure.

### 4.1 Preprocessing Pipeline Invariants
The XDrift preprocessing pipeline implements five strict invariants:
1. **Canonical 5-Tuple Aggregation**: Packets are grouped by bidirectional communication channel. The canonical key pairs $(\text{src\_ip}, \text{src\_port}, \text{dst\_ip}, \text{dst\_port}, \text{proto})$ and $(\text{dst\_ip}, \text{dst\_port}, \text{src\_ip}, \text{src\_port}, \text{proto})$ into the same flow, with the initial packet determining the forward direction.
2. **120-Second Inactivity Timeout**: If the time delta between two consecutive packets on the same 5-tuple exceeds 120.0 seconds, the subsequent packet initiates a new flow session.
3. **Fixed Sequence Length ($N=64$)**: Only the first 64 packets of each flow are retained. The initial packet exchange contains protocol handshakes, TLS Client/Server Hello exchanges, cipher suite negotiations, and initial key exchanges—the most informative signatures for classification.
4. **Channel 0: Signed Normalized Packet Length**:
   $$x_{0, i} = \begin{cases} + \frac{L_i}{1500.0} & \text{if packet } i \text{ is forward (client } \to \text{ server)} \\ - \frac{L_i}{1500.0} & \text{if packet } i \text{ is backward (server } \to \text{ client)} \end{cases}$$
   where $L_i \in [0, 1500]$ is the packet byte length, normalized by the standard Ethernet Maximum Transmission Unit (MTU) of 1500 bytes. This maps lengths to $[-1.0, +1.0]$.
5. **Channel 1: Log-Scaled Inter-Arrival Time (IAT)**:
   $$x_{1, i} = \ln\left(1 + \min(\Delta t_i, 5.0)\right)$$
   where $\Delta t_i = t_i - t_{i-1}$ is the arrival delta in seconds (with $\Delta t_0 = 0$). Capping at 5.0 seconds prevents extreme outliers from dominating numerical optimization, mapping IAT to $[0, \ln(6)] \approx [0, 1.7918]$.
6. **Zero Padding & Validity Mask**: Flows containing fewer than 64 packets are right-padded with zeros. An explicit binary validity mask $m \in \{0, 1\}^{64}$ records $m_i = 1$ for observed packets and $m_i = 0$ for padded positions.
""")

    add_code(cells, r"""
# Load preprocessed test tensors to inspect data representation
test_data_path = os.path.join(project_root, "data/processed/test_data.npz")
test_npz = np.load(test_data_path, allow_pickle=True)

X_test = test_npz['X']              # Shape: (49251, 2, 64)
masks_test = test_npz['masks']      # Shape: (49251, 64)
seq_lens_test = test_npz['seq_lens']# Shape: (49251,)
y_test = test_npz['y']              # Shape: (49251,)

print("=== Processed Test Tensor Shapes ===")
print(f"X (Input Features):    {X_test.shape} (dtype: {X_test.dtype})")
print(f"masks (Validity Mask): {masks_test.shape} (dtype: {masks_test.dtype})")
print(f"seq_lens (Lengths):    {seq_lens_test.shape} (dtype: {seq_lens_test.dtype})")
print(f"y (Class Labels):      {y_test.shape} (dtype: {y_test.dtype})")
print(f"Channel 0 Range (Length): [{X_test[:, 0, :].min():.4f}, {X_test[:, 0, :].max():.4f}]")
print(f"Channel 1 Range (IAT):    [{X_test[:, 1, :].min():.4f}, {X_test[:, 1, :].max():.4f}]")

# Inspect a representative flow sample
sample_idx = 10
print(f"\nSample Flow #{sample_idx} (Label: {'VPN' if y_test[sample_idx]==1 else 'Non-VPN'}, Length: {seq_lens_test[sample_idx]} packets):")
print(f"First 8 Signed Lengths: {np.round(X_test[sample_idx, 0, :8], 4)}")
print(f"First 8 Log IATs:        {np.round(X_test[sample_idx, 1, :8], 4)}")
print(f"First 8 Mask Values:     {masks_test[sample_idx, :8]}")
""")

    add_markdown(cells, r"""
### Figure 1: Flow Construction and Preprocessing Pipeline
We generate a schematic diagram illustrating the transformation from raw PCAP packets to fixed-size input tensors and validity masks.

**Figure 1. Overview of the flow-construction and preprocessing pipeline.** Packets from raw PCAP files are segmented by canonical 5-tuple and a 120-second inactivity timeout. The first 64 packets of each bidirectional flow are extracted, encoding signed packet length normalized by 1500 bytes in Channel 0 and log-transformed inter-arrival times in Channel 1. Short flows are right-padded with zeros, and an auxiliary validity mask tracks unobserved packet positions.
""")

    add_code(cells, r"""
# Generate Figure 1: Flow Construction Pipeline Diagram
fig, ax = plt.subplots(figsize=(10, 4.2))
ax.axis('off')

# Box properties
box_blue = dict(boxstyle="round,pad=0.5", fc="#e8f4f8", ec="#1f77b4", lw=1.5)
box_green = dict(boxstyle="round,pad=0.5", fc="#eafaf1", ec="#2ca02c", lw=1.5)
box_orange = dict(boxstyle="round,pad=0.5", fc="#fef5e7", ec="#ff7f0e", lw=1.5)
box_purple = dict(boxstyle="round,pad=0.5", fc="#f4ecf7", ec="#8e44ad", lw=1.5)

# Pipeline steps
ax.text(0.10, 0.70, "1. Raw PCAP Capture\n• 140 PCAP/PCAPNG files\n• Ethernet frames & TCP/UDP", 
        ha="center", va="center", bbox=box_blue, fontsize=9)
ax.text(0.35, 0.70, "2. Flow Aggregation\n• Canonical 5-tuple matching\n• 120s inactivity timeout", 
        ha="center", va="center", bbox=box_green, fontsize=9)
ax.text(0.65, 0.70, "3. Feature Normalization\n• Channel 0: ± Length / 1500\n• Channel 1: ln(1 + min(Δt, 5))", 
        ha="center", va="center", bbox=box_orange, fontsize=9)
ax.text(0.90, 0.70, "4. Tensor Output\n• Truncate to N=64 packets\n• Zero-pad short flows", 
        ha="center", va="center", bbox=box_purple, fontsize=9)

# Draw arrows
arrow_props = dict(arrowstyle="->", lw=2, color="#555555")
ax.annotate("", xy=(0.22, 0.70), xytext=(0.20, 0.70), arrowprops=arrow_props)
ax.annotate("", xy=(0.50, 0.70), xytext=(0.48, 0.70), arrowprops=arrow_props)
ax.annotate("", xy=(0.78, 0.70), xytext=(0.76, 0.70), arrowprops=arrow_props)

# Mathematical representation summary
ax.text(0.50, 0.25, 
        r"$\mathbf{X} \in \mathbb{R}^{B \times 2 \times 64}, \quad "
        r"X_{0, i} = \pm \frac{L_i}{1500} \in [-1, 1], \quad "
        r"X_{1, i} = \ln(1 + \min(\Delta t_i, 5.0)) \in [0, 1.79], \quad "
        r"\mathbf{m} \in \{0, 1\}^{B \times 64}$",
        ha="center", va="center", fontsize=11, 
        bbox=dict(boxstyle="square,pad=0.6", fc="#ffffff", ec="#cccccc", lw=1.2))

ax.set_title("Figure 1. Overview of the flow-construction and preprocessing pipeline.", fontsize=11, pad=15)
plt.tight_layout()

# Save thesis figures
fig.savefig(os.path.join(figures_dir, "figure1_flow_construction_pipeline.png"), dpi=300, bbox_inches='tight')
fig.savefig(os.path.join(figures_dir, "figure1_flow_construction_pipeline.pdf"), bbox_inches='tight')
plt.show()
""")

    # =========================================================================
    # SECTION 5: The FP32 1D-CNN Architecture
    # =========================================================================
    add_markdown(cells, r"""
---
## Section 5: The FP32 1D-CNN Architecture

### What We Are Investigating
We inspect the neural network architecture chosen for encrypted traffic classification, verifying its parameter count, layer-by-layer tensor dimensions, and convolutional receptive field.

### Architectural Specification: `Compact1DCNN`
The model is a 1D Convolutional Neural Network specifically engineered for edge deployment:
- **Input Dimensions**: $(B, 2, 64)$ — Batch size $B$, 2 feature channels, sequence length 64.
- **Convolutional Block 1**:
  - `Conv1d(in_channels=2, out_channels=32, kernel_size=5, stride=1, padding=2)`
  - `BatchNorm1d(32)` $\to$ `ReLU()` $\to$ `MaxPool1d(kernel_size=2, stride=2)`
  - Output shape: $(B, 32, 32)$. Receptive field: 5 packets.
- **Convolutional Block 2**:
  - `Conv1d(in_channels=32, out_channels=64, kernel_size=5, stride=1, padding=2)`
  - `BatchNorm1d(64)` $\to$ `ReLU()` $\to$ `MaxPool1d(kernel_size=2, stride=2)`
  - Output shape: $(B, 64, 16)$. Receptive field: 14 packets.
- **Convolutional Block 3**:
  - `Conv1d(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=1)`
  - `BatchNorm1d(128)` $\to$ `ReLU()` $\to$ `AdaptiveAvgPool1d(output_size=1)`
  - Output shape: $(B, 128, 1)$. Global temporal aggregation across all packets.
- **Classifier Head**:
  - `Flatten()` $\to$ `Linear(in_features=128, out_features=64)` $\to$ `ReLU()` $\to$ `Dropout(p=0.3)`
  - `Linear(in_features=64, out_features=1)` $\to$ Pre-sigmoid scalar logit $z \in (-\infty, \infty)$.
  - Total parameter count: **44,129 parameters**.

### Why the Model Outputs a Logit Instead of Probability
During training, the network outputs an unbounded raw logit $z$. The loss function is `BCEWithLogitsLoss`:
$$\mathcal{L}(z, y) = \max(z, 0) - z \cdot y + \ln\left(1 + e^{-|z|}\right)$$
This formulation uses the log-sum-exp trick to avoid numerical underflow/overflow when computing probabilities near 0 or 1. During evaluation, predicted probabilities are obtained via the sigmoid function:
$$p = \sigma(z) = \frac{1}{1 + e^{-z}}$$
Class mapping: Non-VPN $= 0$, VPN $= 1$.
""")

    add_code(cells, r"""
# Instantiate model from authoritative source code and inspect parameters
from src.models.cnn1d import Compact1DCNN

model_fp32 = Compact1DCNN()
model_fp32.eval()

# Layer-by-layer parameter inventory
param_table = []
total_params = 0
for name, param in model_fp32.named_parameters():
    num = param.numel()
    total_params += num
    param_table.append((name, list(param.shape), num, param.requires_grad))

print(f"{'Layer / Parameter Name':<32} | {'Shape':<18} | {'Param Count':<12} | {'Trainable'}")
print("-" * 75)
for name, shape, num, req_grad in param_table:
    print(f"{name:<32} | {str(shape):<18} | {num:>12,d} | {req_grad}")
print("-" * 75)
print(f"{'Total Parameter Count':<32} | {'':<18} | {total_params:>12,d} |")

assert total_params == 44129, f"Parameter count discrepancy: Expected 44,129, found {total_params}"

# Verify forward pass on dummy input
dummy_input = torch.randn(2, 2, 64)
dummy_logit = model_fp32(dummy_input)
print(f"\nForward Pass Sanity Check: Input (2, 2, 64) -> Output Logit Shape: {dummy_logit.shape}")
""")

    add_markdown(cells, r"""
### Figure 2: 1D-CNN Model Architecture Diagram
We visualize the complete layer structure, indicating intermediate activation tensor shapes and operator types.

**Figure 2. Architecture of the 1D-CNN used for encrypted traffic classification.** The model processes a $(B, 2, 64)$ input tensor through three 1D convolutional blocks with batch normalization, ReLU activations, and pooling, culminating in global adaptive average pooling and a two-layer fully connected classification head with 44,129 total parameters.
""")

    add_code(cells, r"""
# Generate Figure 2: 1D-CNN Model Architecture
fig, ax = plt.subplots(figsize=(11, 4.5))
ax.axis('off')

# Layer block definitions: (Label, Subtitle, X_pos, Box_color)
blocks = [
    ("Input Tensor", "(B, 2, 64)\nNorm Len + IAT", 0.08, "#e8f4f8", "#1f77b4"),
    ("Conv Block 1", "Conv1d(2->32, k=5)\nBN + ReLU + MaxPool2\n(B, 32, 32)", 0.25, "#eafaf1", "#2ca02c"),
    ("Conv Block 2", "Conv1d(32->64, k=5)\nBN + ReLU + MaxPool2\n(B, 64, 16)", 0.44, "#eafaf1", "#2ca02c"),
    ("Conv Block 3", "Conv1d(64->128, k=3)\nBN + ReLU + AdaptPool1\n(B, 128, 1)", 0.63, "#eafaf1", "#2ca02c"),
    ("Dense Head", "Linear(128->64)+ReLU\nDropout(p=0.3)\n(B, 64)", 0.81, "#fef5e7", "#ff7f0e"),
    ("Output Logit", "Linear(64->1)\nLogit z in (-inf, +inf)\n(B, 1)", 0.95, "#f4ecf7", "#8e44ad"),
]

for title, subtitle, x_pos, fc, ec in blocks:
    ax.text(x_pos, 0.55, f"{title}\n\n{subtitle}", ha="center", va="center",
            bbox=dict(boxstyle="round,pad=0.5", fc=fc, ec=ec, lw=1.5), fontsize=8.5)

# Connect with arrows
arrow_props = dict(arrowstyle="->", lw=2, color="#555555")
ax.annotate("", xy=(0.17, 0.55), xytext=(0.15, 0.55), arrowprops=arrow_props)
ax.annotate("", xy=(0.35, 0.55), xytext=(0.33, 0.55), arrowprops=arrow_props)
ax.annotate("", xy=(0.54, 0.55), xytext=(0.52, 0.55), arrowprops=arrow_props)
ax.annotate("", xy=(0.73, 0.55), xytext=(0.71, 0.55), arrowprops=arrow_props)
ax.annotate("", xy=(0.89, 0.55), xytext=(0.87, 0.55), arrowprops=arrow_props)

# Summary annotation
ax.text(0.50, 0.15, "Total Model Parameters: 44,129  |  Input Channels: 2  |  Sequence Length: 64 Packets", 
        ha="center", va="center", fontsize=10, 
        bbox=dict(boxstyle="square,pad=0.5", fc="#ffffff", ec="#aaaaaa", lw=1.0))

ax.set_title("Figure 2. Architecture of the 1D-CNN used for encrypted traffic classification.", fontsize=11, pad=15)
plt.tight_layout()

fig.savefig(os.path.join(figures_dir, "figure2_cnn1d_architecture.png"), dpi=300, bbox_inches='tight')
fig.savefig(os.path.join(figures_dir, "figure2_cnn1d_architecture.pdf"), bbox_inches='tight')
plt.show()
""")

    # =========================================================================
    # SECTION 6: FP32, PTQ, and QAT — Three Model Representations
    # =========================================================================
    add_markdown(cells, r"""
---
## Section 6: FP32, PTQ, and QAT — Three Model Representations

### What We Are Investigating
We investigate how model weights and activations are converted from 32-bit floating-point numbers into 8-bit integers, comparing post-training quantization against quantization-aware training.

### 6.1 The Mathematics of Uniform Affine Quantization
In PyTorch's quantization engine, real numbers $x \in \mathbb{R}$ are mapped to integer values $q \in [q_{\min}, q_{\max}]$ using uniform affine quantization:

$$q = \operatorname{clamp}\left( \left\lfloor \frac{x}{s} \right\rceil + z, \; q_{\min}, \; q_{\max} \right)$$

where:
- $\lfloor \cdot \rceil$ denotes round-to-nearest-even tie-breaking.
- $s \in \mathbb{R}^+$ is the positive **scale factor**, representing the real-world step size between adjacent integer codes.
- $z \in \mathbb{Z}$ is the **zero-point offset**, an integer ensuring that real zero ($0.0$) maps exactly to a representable integer without precision loss.
- $[q_{\min}, q_{\max}] = [0, 255]$ for unsigned 8-bit integers (`torch.quint8`).
- $[q_{\min}, q_{\max}] = [-128, 127]$ for signed 8-bit integers (`torch.qint8`).

The dequantization approximation $\hat{x} \approx x$ recovered during evaluation or subsequent linear operations is:

$$\hat{x} = s \cdot (q - z)$$

---

### 6.2 PTQ vs QAT Paradigms
1. **FP32 (Floating Point 32)**:
   - Weights and activations use IEEE 754 single-precision floats (1 sign bit, 8 exponent bits, 23 mantissa bits).
   - High dynamic range ($\approx 10^{-38}$ to $10^{38}$), zero quantization error, but high memory bandwidth requirements.
2. **PTQ (Post-Training Quantization)**:
   - The FP32 model is trained to convergence.
   - Layers are fused (`Conv1d + BatchNorm1d + ReLU` $\to$ `ConvReLU1d`) to reduce memory round-trips.
   - The model is calibrated by passing representative training batches through observer modules to calculate static activation ranges $[x_{\min}, x_{\max}]$.
   - Weights and activations are converted to INT8 post-hoc. Fast, but weights cannot adjust to compensate for quantization noise.
3. **QAT (Quantization-Aware Training)**:
   - `FakeQuantize` nodes are inserted into the computation graph.
   - During the forward pass, weights and activations are clamped and rounded to simulate INT8 precision.
   - During backpropagation, standard non-differentiable rounding ($\frac{\partial \lfloor x \rceil}{\partial x} = 0$) is bypassed using the **Straight-Through Estimator (STE)**:
     $$\frac{\partial \hat{x}}{\partial x} \approx \begin{cases} 1 & \text{if } x_{\min} \le x \le x_{\max} \\ 0 & \text{otherwise} \end{cases}$$
   - The model fine-tunes its weights to discover loss minima that are resilient to integer rounding, but can undergo structural parameter restructuring.
""")

    add_code(cells, r"""
# Display model comparison table
print("=== Comparison of FP32, PTQ, and QAT Paradigms ===")
print(f"{'Feature / Metric':<24} | {'FP32 Baseline':<20} | {'PTQ Model':<20} | {'QAT Model':<20}")
print("-" * 92)
print(f"{'Numerical Dtype':<24} | {'torch.float32':<20} | {'torch.quint8/qint8':<20} | {'torch.quint8/qint8':<20}")
print(f"{'Weight Precision':<24} | {'32 bits':<20} | {'8 bits':<20} | {'8 bits':<20}")
print(f"{'Calibration Step':<24} | {'None (Native)':<20} | {'Post-hoc (Histogram)':<20} | {'Simulated in Training':<20}")
print(f"{'Training Cost':<24} | {'Standard Backprop':<20} | {'Zero Retraining':<20} | {'Fine-tuning + STE':<20}")
print(f"{'Checkpoint Size':<24} | {'188.7 KB':<20} | {'53.0 KB (3.56x comp)':<20} | {'53.0 KB (3.56x comp)':<20}")
print(f"{'Execution Path':<24} | {'Floating-Point ALU':<20} | {'QNNPACK INT8 SIMD':<20} | {'QNNPACK INT8 SIMD':<20}")
print(f"{'Expected Attribution':<24} | {'Reference Explanation':<20} | {'Slight Perturbation':<20} | {'Severe Restructuring':<20}")
""")

    add_markdown(cells, r"""
### Figure 3: Conceptual Workflows of FP32, PTQ, and QAT
We illustrate the training, calibration, and conversion pipelines for all three model representations.

**Figure 3. Conceptual comparison of FP32, PTQ, and QAT model workflows.** The FP32 model undergoes standard training on full-precision floating-point tensors. PTQ fuses layers and records activation distributions on a calibration set to compute static scales and zero points without weight updates. QAT inserts fake-quantization modules and uses the Straight-Through Estimator to adapt model weights to simulated integer rounding prior to INT8 conversion.
""")

    add_code(cells, r"""
# Generate Figure 3: Conceptual Quantization Workflows Diagram
fig, ax = plt.subplots(figsize=(11, 4.5))
ax.axis('off')

# FP32 Workflow
ax.text(0.12, 0.80, "FP32 Workflow", ha="center", va="center", fontsize=10, weight="bold", color="#1f77b4")
ax.text(0.12, 0.60, "Raw PCAP Data\n(Training Split)", ha="center", va="center", 
        bbox=dict(boxstyle="round,pad=0.4", fc="#e8f4f8", ec="#1f77b4", lw=1.2), fontsize=8.5)
ax.text(0.12, 0.35, "Full-Precision Training\n(Adam, lr=1e-3, 30 epochs)\nFP32 Parameters", ha="center", va="center", 
        bbox=dict(boxstyle="round,pad=0.4", fc="#e8f4f8", ec="#1f77b4", lw=1.2), fontsize=8.5)
ax.text(0.12, 0.10, "FP32 Model Checkpoint\n(188.7 KB, 44,129 params)", ha="center", va="center", 
        bbox=dict(boxstyle="square,pad=0.4", fc="#ffffff", ec="#1f77b4", lw=1.5), fontsize=8.5)

# PTQ Workflow
ax.text(0.50, 0.80, "PTQ Workflow (Post-Training)", ha="center", va="center", fontsize=10, weight="bold", color="#ff7f0e")
ax.text(0.50, 0.60, "Trained FP32 Model\n(Weights Frozen)", ha="center", va="center", 
        bbox=dict(boxstyle="round,pad=0.4", fc="#fef5e7", ec="#ff7f0e", lw=1.2), fontsize=8.5)
ax.text(0.50, 0.35, "Fuse Layers + Observe Range\n(Histogram Calibration)\nCompute Scale (s) & Zero-Point (z)", ha="center", va="center", 
        bbox=dict(boxstyle="round,pad=0.4", fc="#fef5e7", ec="#ff7f0e", lw=1.2), fontsize=8.5)
ax.text(0.50, 0.10, "Converted PTQ INT8\n(53.0 KB, QNNPACK Engine)", ha="center", va="center", 
        bbox=dict(boxstyle="square,pad=0.4", fc="#ffffff", ec="#ff7f0e", lw=1.5), fontsize=8.5)

# QAT Workflow
ax.text(0.88, 0.80, "QAT Workflow (Quantization-Aware)", ha="center", va="center", fontsize=10, weight="bold", color="#2ca02c")
ax.text(0.88, 0.60, "Fuse Layers + Insert\nFakeQuantize Modules", ha="center", va="center", 
        bbox=dict(boxstyle="round,pad=0.4", fc="#eafaf1", ec="#2ca02c", lw=1.2), fontsize=8.5)
ax.text(0.88, 0.35, "Fine-tune with STE Gradients\n(Learn weights resilient\nto rounding noise)", ha="center", va="center", 
        bbox=dict(boxstyle="round,pad=0.4", fc="#eafaf1", ec="#2ca02c", lw=1.2), fontsize=8.5)
ax.text(0.88, 0.10, "Converted QAT INT8\n(53.0 KB, Saturated Output)", ha="center", va="center", 
        bbox=dict(boxstyle="square,pad=0.4", fc="#ffffff", ec="#2ca02c", lw=1.5), fontsize=8.5)

# Connect vertical arrows
arrow = dict(arrowstyle="->", lw=1.5, color="#666666")
ax.annotate("", xy=(0.12, 0.48), xytext=(0.12, 0.52), arrowprops=arrow)
ax.annotate("", xy=(0.12, 0.22), xytext=(0.12, 0.25), arrowprops=arrow)
ax.annotate("", xy=(0.50, 0.48), xytext=(0.50, 0.52), arrowprops=arrow)
ax.annotate("", xy=(0.50, 0.22), xytext=(0.50, 0.25), arrowprops=arrow)
ax.annotate("", xy=(0.88, 0.48), xytext=(0.88, 0.52), arrowprops=arrow)
ax.annotate("", xy=(0.88, 0.22), xytext=(0.88, 0.25), arrowprops=arrow)

ax.set_title("Figure 3. Conceptual comparison of FP32, PTQ, and QAT model workflows.", fontsize=11, pad=15)
plt.tight_layout()

fig.savefig(os.path.join(figures_dir, "figure3_quantization_workflows.png"), dpi=300, bbox_inches='tight')
fig.savefig(os.path.join(figures_dir, "figure3_quantization_workflows.pdf"), bbox_inches='tight')
plt.show()
""")

    # =========================================================================
    # SECTION 7: Load Checkpoints and Reproduce Predictions
    # =========================================================================
    add_markdown(cells, r"""
---
## Section 7: Load Checkpoints and Reproduce Predictions

### What We Are Investigating
We load the raw serialized model checkpoints from disk, reconstruct the PyTorch model graphs, and execute a deterministic forward pass over all 49,251 test flows. We compare newly recomputed logits directly against the saved prediction cache.

### Why It Matters
Verifying deterministic cache agreement establishes that:
1. Checkpoint files have not suffered silent corruption.
2. The PyTorch execution environment and quantization backend match the exact configuration used to generate the published metrics.
3. Subsequent analysis throughout this notebook operates on mathematically identical logit values ($0.00000000\text{e}+00$ maximum residual).
""")

    add_code(cells, r"""
import torch.ao.quantization as quantization
from src.models.cnn1d import Compact1DCNN, fuse_model_ptq

def load_int8_checkpoint(checkpoint_path: str) -> torch.nn.Module:
    '''Reconstruct INT8 quantized model and load serialized state dict.'''
    torch.backends.quantized.engine = 'qnnpack'
    payload = torch.load(checkpoint_path, map_location='cpu', weights_only=False)
    
    base_model = Compact1DCNN().eval()
    fused_model = fuse_model_ptq(base_model)
    fused_model.qconfig = quantization.get_default_qconfig('qnnpack')
    prep_model = quantization.prepare(fused_model)
    
    # Run dummy input to initialize observer shapes
    dummy_x = torch.zeros(1, 2, 64)
    prep_model(dummy_x)
    
    int8_model = quantization.convert(prep_model)
    int8_model.load_state_dict(payload['state_dict'])
    int8_model.eval()
    return int8_model

# Load raw checkpoints
fp32_ckpt_path = os.path.join(project_root, "artifacts/checkpoints/fp32_seed_42.pt")
ptq_ckpt_path = os.path.join(project_root, "artifacts/quantized_models/ptq_seed_42.pt")
qat_ckpt_path = os.path.join(project_root, "artifacts/quantized_models/qat_seed_42.pt")

model_fp32 = Compact1DCNN().eval()
payload_fp32 = torch.load(fp32_ckpt_path, map_location='cpu', weights_only=False)
model_fp32.load_state_dict(payload_fp32['state_dict'])

model_ptq = load_int8_checkpoint(ptq_ckpt_path)
model_qat = load_int8_checkpoint(qat_ckpt_path)

print("Successfully reconstructed FP32, PTQ, and QAT model graphs.")

# Load saved test predictions to verify exact cache agreement
test_pred_path = os.path.join(project_root, "results/predictions/test_predictions.npz")
cached_preds = np.load(test_pred_path, allow_pickle=True)

fp32_cached_logits = cached_preds['fp32_logits']
ptq_cached_logits = cached_preds['ptq_logits']
qat_cached_logits = cached_preds['qat_logits']

# Forward inference on first 100 test samples to verify zero residual
X_test_tensor = torch.from_numpy(X_test[:100]).float()

with torch.no_grad():
    fp32_recomputed = model_fp32(X_test_tensor).squeeze(-1).numpy()
    ptq_recomputed = model_ptq(X_test_tensor).squeeze(-1).numpy()
    qat_recomputed = model_qat(X_test_tensor).squeeze(-1).numpy()

diff_fp32 = np.max(np.abs(fp32_recomputed - fp32_cached_logits[:100]))
diff_ptq = np.max(np.abs(ptq_recomputed - ptq_cached_logits[:100]))
diff_qat = np.max(np.abs(qat_recomputed - qat_cached_logits[:100]))

print("\n=== Deterministic Inference Residual Check (First 100 Test Flows) ===")
print(f"FP32 Max Absolute Residual: {diff_fp32:.8e}")
print(f"PTQ  Max Absolute Residual: {diff_ptq:.8e}")
print(f"QAT  Max Absolute Residual: {diff_qat:.8e}")

assert diff_fp32 < 1e-6, "FP32 inference residual mismatch!"
assert diff_ptq < 1e-6, "PTQ inference residual mismatch!"
assert diff_qat < 1e-6, "QAT inference residual mismatch!"

print("\nDETERMINISTIC INFERENCE VERIFICATION: PASS. Zero residual vs saved prediction cache.")
""")
