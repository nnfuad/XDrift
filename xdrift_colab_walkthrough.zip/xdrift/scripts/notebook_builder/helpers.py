"""Helper functions for notebook construction."""

import nbformat as nbf

def add_markdown(cells, text: str):
    """Add a markdown cell with stripped leading/trailing empty lines."""
    cells.append(nbf.v4.new_markdown_cell(text.strip()))

def add_code(cells, text: str):
    """Add a code cell with stripped leading/trailing empty lines."""
    cells.append(nbf.v4.new_code_cell(text.strip()))
