"""Part 3: Predictive Performance and Calibration (Sections 8, 9, 10, 11) for XDrift Master Notebook."""

from .helpers import add_markdown, add_code

def build_part3(cells):
    # =========================================================================
    # SECTION 8: Predictive Performance
    # =========================================================================
    add_markdown(cells, r"""
---
## Section 8: Predictive Performance

### What We Are Investigating
We evaluate the classification performance of FP32, PTQ, and QAT models on the 49,251 held-out test flows. We calculate both threshold-independent ranking metrics (ROC-AUC, PR-AUC) and operational threshold-dependent metrics (Accuracy, Balanced Accuracy, Precision, Recall, F1-Score).

### Metric Definitions
1. **Receiver Operating Characteristic Area Under Curve (ROC-AUC)**:
   Measures ranking ability across all possible classification thresholds:
   $$\text{ROC-AUC} = \int_{0}^{1} \text{TPR}(\tau) \, d(\text{FPR}(\tau))$$
   Equivalent to the Wilcoxon-Mann-Whitney probability that a randomly chosen positive (VPN) flow receives a higher predicted score than a randomly chosen negative (Non-VPN) flow.
2. **Precision-Recall Area Under Curve (PR-AUC)**:
   $$\text{PR-AUC} = \int_{0}^{1} \text{Precision}(R) \, dR$$
   In highly imbalanced datasets (such as our 5.47% VPN prevalence), PR-AUC is far more informative than ROC-AUC because it directly penalizes false positives against the small minority class without being masked by a vast true negative count.
3. **F1-Score ($F_1$)**:
   The harmonic mean of precision and recall:
   $$F_1 = 2 \cdot \frac{\text{Precision} \cdot \text{Recall}}{\text{Precision} + \text{Recall}}$$
4. **Balanced Accuracy**:
   $$\text{Balanced Accuracy} = \frac{\text{Sensitivity} + \text{Specificity}}{2} = \frac{1}{2}\left(\frac{\text{TP}}{\text{TP} + \text{FN}} + \frac{\text{TN}}{\text{TN} + \text{FP}}\right)$$
""")

    add_code(cells, r"""
# Pure NumPy metric implementations for exact, zero-warning calculation
def compute_roc_auc_np(y_true: np.ndarray, y_score: np.ndarray) -> float:
    order = np.argsort(y_score, kind='mergesort')[::-1]
    y_score_sorted = y_score[order]
    y_true_sorted = y_true[order]
    distinct_idxs = np.where(np.diff(y_score_sorted))[0]
    threshold_idxs = np.r_[distinct_idxs, y_true.size - 1]
    tps = np.cumsum(y_true_sorted)[threshold_idxs]
    fps = 1 + threshold_idxs - tps
    tpr = np.r_[0, tps / tps[-1]]
    fpr = np.r_[0, fps / fps[-1]]
    return float(np.trapezoid(tpr, fpr))

def compute_pr_auc_np(y_true: np.ndarray, y_score: np.ndarray) -> float:
    order = np.argsort(y_score, kind='mergesort')[::-1]
    y_score_sorted = y_score[order]
    y_true_sorted = y_true[order]
    distinct_idxs = np.where(np.diff(y_score_sorted))[0]
    threshold_idxs = np.r_[distinct_idxs, y_true.size - 1]
    tps = np.cumsum(y_true_sorted)[threshold_idxs]
    fps = 1 + threshold_idxs - tps
    precision = tps / (tps + fps)
    recall = tps / tps[-1]
    recall_diffs = np.r_[recall[0], np.diff(recall)]
    return float(np.sum(precision * recall_diffs))

def compute_roc_curve_np(y_true: np.ndarray, y_score: np.ndarray):
    order = np.argsort(y_score, kind='mergesort')[::-1]
    y_score_sorted = y_score[order]
    y_true_sorted = y_true[order]
    distinct_idxs = np.where(np.diff(y_score_sorted))[0]
    threshold_idxs = np.r_[distinct_idxs, y_true.size - 1]
    tps = np.cumsum(y_true_sorted)[threshold_idxs]
    fps = 1 + threshold_idxs - tps
    tpr = np.r_[0, tps / tps[-1]]
    fpr = np.r_[0, fps / fps[-1]]
    return fpr, tpr

def compute_pr_curve_np(y_true: np.ndarray, y_score: np.ndarray):
    order = np.argsort(y_score, kind='mergesort')[::-1]
    y_score_sorted = y_score[order]
    y_true_sorted = y_true[order]
    distinct_idxs = np.where(np.diff(y_score_sorted))[0]
    threshold_idxs = np.r_[distinct_idxs, y_true.size - 1]
    tps = np.cumsum(y_true_sorted)[threshold_idxs]
    fps = 1 + threshold_idxs - tps
    precision = np.r_[1.0, tps / (tps + fps)]
    recall = np.r_[0.0, tps / tps[-1]]
    return precision, recall

def compute_confusion_matrix_np(y_true: np.ndarray, y_prob: np.ndarray, threshold: float):
    y_pred = (y_prob >= threshold).astype(int)
    tn = int(np.sum((y_pred == 0) & (y_true == 0)))
    fp = int(np.sum((y_pred == 1) & (y_true == 0)))
    fn = int(np.sum((y_pred == 0) & (y_true == 1)))
    tp = int(np.sum((y_pred == 1) & (y_true == 1)))
    acc = (tp + tn) / len(y_true)
    sens = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    spec = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    bal_acc = 0.5 * (sens + spec)
    prec = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    f1 = 2 * (prec * sens) / (prec + sens) if (prec + sens) > 0 else 0.0
    return {'tn': tn, 'fp': fp, 'fn': fn, 'tp': tp,
            'accuracy': acc, 'balanced_accuracy': bal_acc,
            'precision': prec, 'recall': sens, 'specificity': spec, 'f1': f1}

# Load probabilities
fp32_probs = cached_preds['fp32_probs']
ptq_probs = cached_preds['ptq_probs']
qat_probs = cached_preds['qat_probs']

# Ranking metrics
fp32_roc = compute_roc_auc_np(y_test, fp32_probs)
ptq_roc = compute_roc_auc_np(y_test, ptq_probs)
qat_roc = compute_roc_auc_np(y_test, qat_probs)

fp32_pr = compute_pr_auc_np(y_test, fp32_probs)
ptq_pr = compute_pr_auc_np(y_test, ptq_probs)
qat_pr = compute_pr_auc_np(y_test, qat_probs)

# Threshold-calibrated metrics (tau: FP32=0.900, PTQ=0.900, QAT=0.680)
m_fp32 = compute_confusion_matrix_np(y_test, fp32_probs, 0.900)
m_ptq = compute_confusion_matrix_np(y_test, ptq_probs, 0.900)
m_qat = compute_confusion_matrix_np(y_test, qat_probs, 0.680)

print("=== Table 1: Comprehensive Predictive Performance on Test Partition (N=49,251) ===")
print(f"{'Performance Metric':<26} | {'FP32 Baseline':<16} | {'PTQ Model':<16} | {'QAT Model':<16}")
print("-" * 82)
print(f"{'ROC-AUC (Ranking)':<26} | {fp32_roc:>16.4f} | {ptq_roc:>16.4f} | {qat_roc:>16.4f}")
print(f"{'PR-AUC (Minority)':<26} | {fp32_pr:>16.4f} | {ptq_pr:>16.4f} | {qat_pr:>16.4f}")
print(f"{'Decision Threshold (tau)':<26} | {'0.900':>16} | {'0.900':>16} | {'0.680':>16}")
print(f"{'Accuracy (%)':<26} | {m_fp32['accuracy']*100:>15.2f}% | {m_ptq['accuracy']*100:>15.2f}% | {m_qat['accuracy']*100:>15.2f}%")
print(f"{'Balanced Accuracy (%)':<26} | {m_fp32['balanced_accuracy']*100:>15.2f}% | {m_ptq['balanced_accuracy']*100:>15.2f}% | {m_qat['balanced_accuracy']*100:>15.2f}%")
print(f"{'Precision (%)':<26} | {m_fp32['precision']*100:>15.2f}% | {m_ptq['precision']*100:>15.2f}% | {m_qat['precision']*100:>15.2f}%")
print(f"{'Recall / Sensitivity (%)':<26} | {m_fp32['recall']*100:>15.2f}% | {m_ptq['recall']*100:>15.2f}% | {m_qat['recall']*100:>15.2f}%")
print(f"{'F1-Score':<26} | {m_fp32['f1']:>16.4f} | {m_ptq['f1']:>16.4f} | {m_qat['f1']:>16.4f}")
print(f"{'Positive Calls':<26} | {m_fp32['tp']+m_fp32['fp']:>16,d} | {m_ptq['tp']+m_ptq['fp']:>16,d} | {m_qat['tp']+m_qat['fp']:>16,d}")
print("-" * 82)
""")

    add_markdown(cells, r"""
### Figures 4, 5, and 6: Confusion Matrices, ROC Curves, and PR Curves
We generate thesis-quality visualizations comparing the three models across operating points and ranking thresholds.

**Figure 4. Confusion matrices for FP32, PTQ, and QAT models on the held-out test set.** Each 2$\times$2 matrix displays True Negatives (TN), False Positives (FP), False Negatives (FN), and True Positives (TP) under validation-calibrated thresholds ($\tau=0.900$ for FP32 and PTQ; $\tau=0.680$ for QAT).  
**Figure 5. Receiver operating characteristic curves for FP32, PTQ, and QAT models.** Compares True Positive Rate against False Positive Rate across all thresholds.  
**Figure 6. Precision-recall curves for FP32, PTQ, and QAT models.** The horizontal dashed line denotes random classifier baseline prevalence ($0.0547$).
""")

    add_code(cells, r"""
# Figure 4: Confusion Matrices
fig, axes = plt.subplots(1, 3, figsize=(12, 3.8))
conf_data = [
    ("FP32 (tau=0.900)", m_fp32),
    ("PTQ (tau=0.900)", m_ptq),
    ("QAT (tau=0.680)", m_qat),
]

for ax, (title, m) in zip(axes, conf_data):
    cm = np.array([[m['tn'], m['fp']], [m['fn'], m['tp']]])
    im = ax.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
    ax.set_title(title, fontsize=10, pad=10)
    ax.set_xticks([0, 1])
    ax.set_yticks([0, 1])
    ax.set_xticklabels(['Non-VPN', 'VPN'])
    ax.set_yticklabels(['Non-VPN', 'VPN'])
    ax.set_xlabel('Predicted Label')
    ax.set_ylabel('True Label')
    
    # Text annotations
    thresh = cm.max() / 2.0
    for i in range(2):
        for j in range(2):
            val = cm[i, j]
            pct = (val / len(y_test)) * 100.0
            color = "white" if val > thresh else "black"
            lbl = "TN" if (i==0 and j==0) else "FP" if (i==0 and j==1) else "FN" if (i==1 and j==0) else "TP"
            ax.text(j, i, f"{lbl}\n{val:,d}\n({pct:.2f}%)", ha="center", va="center", color=color, fontsize=8.5)

plt.tight_layout()
fig.savefig(os.path.join(figures_dir, "figure4_confusion_matrices.png"), dpi=300, bbox_inches='tight')
fig.savefig(os.path.join(figures_dir, "figure4_confusion_matrices.pdf"), bbox_inches='tight')
plt.show()

# Figure 5 & 6: ROC and PR Curves
fpr_fp32, tpr_fp32 = compute_roc_curve_np(y_test, fp32_probs)
fpr_ptq, tpr_ptq = compute_roc_curve_np(y_test, ptq_probs)
fpr_qat, tpr_qat = compute_roc_curve_np(y_test, qat_probs)

prec_fp32, rec_fp32 = compute_pr_curve_np(y_test, fp32_probs)
prec_ptq, rec_ptq = compute_pr_curve_np(y_test, ptq_probs)
prec_qat, rec_qat = compute_pr_curve_np(y_test, qat_probs)

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))

# ROC Curves
ax1.plot(fpr_fp32, tpr_fp32, label=f'FP32 (AUC = {fp32_roc:.4f})', color='#1f77b4', lw=1.8)
ax1.plot(fpr_ptq, tpr_ptq, label=f'PTQ (AUC = {ptq_roc:.4f})', color='#ff7f0e', lw=1.8, linestyle='--')
ax1.plot(fpr_qat, tpr_qat, label=f'QAT (AUC = {qat_roc:.4f})', color='#2ca02c', lw=1.8, linestyle=':')
ax1.plot([0, 1], [0, 1], 'k--', alpha=0.4, label='Random Chance')
ax1.set_xlabel('False Positive Rate (1 - Specificity)')
ax1.set_ylabel('True Positive Rate (Sensitivity)')
ax1.set_title('(a) Receiver Operating Characteristic (ROC)')
ax1.legend(loc='lower right')
ax1.grid(True, linestyle='--', alpha=0.3)

# PR Curves
prevalence = np.mean(y_test)
ax2.plot(rec_fp32, prec_fp32, label=f'FP32 (PR-AUC = {fp32_pr:.4f})', color='#1f77b4', lw=1.8)
ax2.plot(rec_ptq, prec_ptq, label=f'PTQ (PR-AUC = {ptq_pr:.4f})', color='#ff7f0e', lw=1.8, linestyle='--')
ax2.plot(rec_qat, prec_qat, label=f'QAT (PR-AUC = {qat_pr:.4f})', color='#2ca02c', lw=1.8, linestyle=':')
ax2.axhline(prevalence, color='k', linestyle='--', alpha=0.4, label=f'Prevalence ({prevalence:.4f})')
ax2.set_xlabel('Recall (Sensitivity)')
ax2.set_ylabel('Precision (Positive Predictive Value)')
ax2.set_title('(b) Precision-Recall (PR) Curves')
ax2.legend(loc='lower left')
ax2.grid(True, linestyle='--', alpha=0.3)

plt.tight_layout()
fig.savefig(os.path.join(figures_dir, "figure5_roc_curves.png"), dpi=300, bbox_inches='tight')
fig.savefig(os.path.join(figures_dir, "figure5_roc_curves.pdf"), bbox_inches='tight')
fig.savefig(os.path.join(figures_dir, "figure6_pr_curves.png"), dpi=300, bbox_inches='tight')
fig.savefig(os.path.join(figures_dir, "figure6_pr_curves.pdf"), bbox_inches='tight')
plt.show()
""")

    # =========================================================================
    # SECTION 9: Threshold Selection and Operating Points
    # =========================================================================
    add_markdown(cells, r"""
---
## Section 9: Threshold Selection and Operating Points

### What We Are Investigating
We investigate how classification decision thresholds are selected, why they must be calibrated on validation data, and what happens when an operating threshold from an FP32 model is blindly transferred to a quantized model.

### The Validation Calibration Rule
In machine learning engineering, optimizing decision thresholds on the held-out test set constitutes **methodological snooping (leakage)**. In the XDrift protocol:
- Thresholds are tuned on the independent Validation split (69,564 flows) to maximize F1-score:
  $$\tau^* = \arg\max_{\tau \in [0, 1]} F_1(\tau; \mathcal{D}_{\text{val}})$$
- Optimal validation thresholds: $\tau_{\text{FP32}}^* = 0.900$, $\tau_{\text{PTQ}}^* = 0.900$, $\tau_{\text{QAT}}^* = 0.680$.

### The Catastrophic Failure of Threshold Transfer
A common operational defect in production deployments occurs when an engineer replaces an FP32 model checkpoint with an INT8-quantized checkpoint inside an existing alerting pipeline without re-tuning the decision threshold.

Below, we demonstrate the catastrophic consequence of reusing the FP32 threshold ($\tau=0.900$) on the QAT model.
""")

    add_code(cells, r"""
# Reusing tau = 0.900 on QAT
m_qat_reused = compute_confusion_matrix_np(y_test, qat_probs, 0.900)

print("=== Demonstration of Threshold Transfer Failure (Reusing tau=0.900 on QAT) ===")
print(f"FP32 Baseline (tau=0.900): Positive Calls = {m_fp32['tp']+m_fp32['fp']:,d} | F1 = {m_fp32['f1']:.4f} | Recall = {m_fp32['recall']*100:.2f}%")
print(f"QAT Reused    (tau=0.900): Positive Calls = {m_qat_reused['tp']+m_qat_reused['fp']:,d} | F1 = {m_qat_reused['f1']:.4f} | Recall = {m_qat_reused['recall']*100:.2f}%")
print(f"QAT Calibrated(tau=0.680): Positive Calls = {m_qat['tp']+m_qat['fp']:,d} | F1 = {m_qat['f1']:.4f} | Recall = {m_qat['recall']*100:.2f}%")

print("\nConfusion Matrix for QAT under Reused Threshold (tau=0.900):")
print(f"  TN = {m_qat_reused['tn']:,d}  |  FP = {m_qat_reused['fp']:,d}")
print(f"  FN = {m_qat_reused['fn']:,d}   |  TP = {m_qat_reused['tp']:,d}")

# Prediction flips
flips_ptq = np.sum((fp32_probs >= 0.900) != (ptq_probs >= 0.900))
flips_qat_calib = np.sum((fp32_probs >= 0.900) != (qat_probs >= 0.680))
flips_qat_reused = np.sum((fp32_probs >= 0.900) != (qat_probs >= 0.900))

print(f"\nPrediction Flips vs FP32 across all {len(y_test):,d} Test Flows:")
print(f"  FP32 vs PTQ (tau=0.900):          {flips_ptq:>6,d} flips ({flips_ptq/len(y_test)*100:.2f}%)")
print(f"  FP32 vs QAT (tau=0.680, calib):   {flips_qat_calib:>6,d} flips ({flips_qat_calib/len(y_test)*100:.2f}%)")
print(f"  FP32 vs QAT (tau=0.900, REUSED):  {flips_qat_reused:>6,d} flips ({flips_qat_reused/len(y_test)*100:.2f}%)")
""")

    add_markdown(cells, r"""
### Plain-Language Interpretation: Why Did QAT Produce 0 Positive Calls?
Under $\tau=0.900$, the QAT model produced **zero positive calls** ($\text{TP}=0, \text{FP}=0$), completely missing all 2,693 VPN flows ($\text{Recall}=0.0000, F_1=0.0000$). Exactly 4,121 test predictions flipped from positive to negative.

This collapse does **not** occur because QAT lacks discriminative ability (its ROC-AUC is $0.9834$, higher than FP32). Rather, it occurs because integer quantization compressed the QAT output distribution so severely that **no prediction in the entire test set can exceed 0.7338**. This mathematical phenomenon is investigated forensically in Section 11.
""")

    # =========================================================================
    # SECTION 10: Probability Calibration and Murphy Decomposition
    # =========================================================================
    add_markdown(cells, r"""
---
## Section 10: Probability Calibration and Murphy Decomposition

### What We Are Investigating
We investigate whether predicted model probabilities represent true empirical event likelihoods. A model is well-calibrated if, among instances assigned a predicted probability $p \approx 0.80$, approximately 80% are truly positive (VPN).

### Murphy's Brier Score Decomposition (1973)
The Brier score measures mean squared probability error:
$$\text{BS} = \frac{1}{N}\sum_{i=1}^{N} (p_i - y_i)^2$$
Murphy (1973) proved that the Brier score can be decomposed into three orthogonal terms:
$$\text{Brier Score} = \text{Reliability} - \text{Resolution} + \text{Uncertainty}$$

where:
1. **Uncertainty ($\bar{y}(1 - \bar{y})$)**: The intrinsic variance of the dataset base rate $\bar{y} = \frac{1}{N}\sum y_i$. This is independent of model predictions.
2. **Reliability ($\sum \frac{n_k}{N} (\bar{p}_k - \bar{y}_k)^2$)**: The weighted squared difference between average confidence and empirical accuracy within bin $k$. **Lower is better** ($0.0$ denotes perfect calibration).
3. **Resolution ($\sum \frac{n_k}{N} (\bar{y}_k - \bar{y})^2$)**: The ability of the model to sort instances into bins with empirical rates differing from the base rate. **Higher is better** (measures discrimination).
""")

    add_code(cells, r"""
def compute_murphy_decomposition(y_true: np.ndarray, y_prob: np.ndarray, n_bins: int = 10):
    brier = float(np.mean((y_prob - y_true) ** 2))
    base_rate = float(np.mean(y_true))
    uncertainty = float(base_rate * (1.0 - base_rate))
    
    bin_edges = np.linspace(0.0, 1.0, n_bins + 1)
    n = len(y_true)
    
    reliability = 0.0
    resolution = 0.0
    ece = 0.0
    bin_confs, bin_accs, bin_counts = [], [], []
    
    for i in range(n_bins):
        low, high = bin_edges[i], bin_edges[i+1]
        mask = (y_prob >= low) & (y_prob <= high if i == n_bins-1 else y_prob < high)
        count = int(np.sum(mask))
        if count > 0:
            mean_p = float(np.mean(y_prob[mask]))
            acc = float(np.mean(y_true[mask]))
            diff = abs(acc - mean_p)
            ece += (count / n) * diff
            reliability += (count / n) * ((mean_p - acc) ** 2)
            resolution += (count / n) * ((acc - base_rate) ** 2)
            bin_confs.append(mean_p)
            bin_accs.append(acc)
            bin_counts.append(count)
        else:
            bin_confs.append(0.5 * (low + high))
            bin_accs.append(0.0)
            bin_counts.append(0)
            
    return {
        'brier': brier, 'uncertainty': uncertainty, 'reliability': reliability,
        'resolution': resolution, 'ece': ece, 'confs': bin_confs, 'accs': bin_accs, 'counts': bin_counts
    }

cal_fp32 = compute_murphy_decomposition(y_test, fp32_probs)
cal_ptq = compute_murphy_decomposition(y_test, ptq_probs)
cal_qat = compute_murphy_decomposition(y_test, qat_probs)

print("=== Murphy (1973) Calibration Decomposition and ECE ===")
print(f"{'Metric':<28} | {'FP32':<14} | {'PTQ':<14} | {'QAT':<14}")
print("-" * 75)
print(f"{'Brier Score (Total)':<28} | {cal_fp32['brier']:>14.6f} | {cal_ptq['brier']:>14.6f} | {cal_qat['brier']:>14.6f}")
print(f"{'Uncertainty (Base Rate)':<28} | {cal_fp32['uncertainty']:>14.6f} | {cal_ptq['uncertainty']:>14.6f} | {cal_qat['uncertainty']:>14.6f}")
print(f"{'Reliability (Lower is Best)':<28} | {cal_fp32['reliability']:>14.6f} | {cal_ptq['reliability']:>14.6f} | {cal_qat['reliability']:>14.6f}")
print(f"{'Resolution (Higher is Best)':<28} | {cal_fp32['resolution']:>14.6f} | {cal_ptq['resolution']:>14.6f} | {cal_qat['resolution']:>14.6f}")
print(f"{'Sum Check (Rel - Res + Unc)':<28} | {cal_fp32['reliability']-cal_fp32['resolution']+cal_fp32['uncertainty']:>14.6f} | {cal_ptq['reliability']-cal_ptq['resolution']+cal_ptq['uncertainty']:>14.6f} | {cal_qat['reliability']-cal_qat['resolution']+cal_qat['uncertainty']:>14.6f}")
print(f"{'Expected Calib Error (ECE)':<28} | {cal_fp32['ece']:>14.6f} | {cal_ptq['ece']:>14.6f} | {cal_qat['ece']:>14.6f}")
""")

    add_markdown(cells, r"""
### Figure 7: Reliability Diagrams and Probability Distributions
We generate reliability diagrams plotting empirical accuracy against confidence bins, alongside probability histograms.

**Figure 7. Reliability diagrams and predicted-probability distributions for FP32, PTQ, and QAT.** The top panels display calibration curves across 10 confidence bins against the diagonal of perfect calibration. The bottom panels display predicted-probability histograms, revealing that QAT predictions are compressed strictly into the interval $[0.007, 0.734]$.
""")

    add_code(cells, r"""
# Generate Figure 7: Calibration Diagrams and Histograms
fig, axes = plt.subplots(2, 3, figsize=(12, 6.5))
models_cal = [("FP32 Baseline", fp32_probs, cal_fp32, '#1f77b4'),
              ("PTQ Model", ptq_probs, cal_ptq, '#ff7f0e'),
              ("QAT Model", qat_probs, cal_qat, '#2ca02c')]

for col, (title, probs, c_data, color) in enumerate(models_cal):
    # Reliability curve
    ax_top = axes[0, col]
    ax_top.plot([0, 1], [0, 1], 'k--', alpha=0.5, label='Perfect Calibration')
    valid_mask = np.array(c_data['counts']) > 0
    ax_top.plot(np.array(c_data['confs'])[valid_mask], np.array(c_data['accs'])[valid_mask], 
                marker='s', color=color, lw=1.8, label=f'ECE = {c_data["ece"]:.4f}')
    ax_top.set_xlim(-0.02, 1.02)
    ax_top.set_ylim(-0.02, 1.02)
    ax_top.set_xlabel('Predicted Probability (Confidence)')
    ax_top.set_ylabel('Empirical Accuracy')
    ax_top.set_title(f"{title}: Reliability Diagram", fontsize=10)
    ax_top.legend(loc='upper left', fontsize=8.5)
    ax_top.grid(True, linestyle='--', alpha=0.3)
    
    # Histogram of predicted probabilities
    ax_bot = axes[1, col]
    ax_bot.hist(probs, bins=25, range=(0, 1), color=color, alpha=0.75, edgecolor='black', lw=0.5)
    ax_bot.set_yscale('log')
    ax_bot.set_xlabel('Predicted Probability')
    ax_bot.set_ylabel('Flow Count (Log Scale)')
    ax_bot.set_title(f"{title}: Probability Histogram", fontsize=10)
    ax_bot.grid(True, linestyle='--', alpha=0.3)

plt.tight_layout()
fig.savefig(os.path.join(figures_dir, "figure7_calibration_reliability.png"), dpi=300, bbox_inches='tight')
fig.savefig(os.path.join(figures_dir, "figure7_calibration_reliability.pdf"), bbox_inches='tight')
plt.show()
""")

    # =========================================================================
    # SECTION 11: Forensic Investigation of QAT Output Saturation
    # =========================================================================
    add_markdown(cells, r"""
---
## Section 11: Forensic Investigation of QAT Output Saturation

### What We Are Investigating
We perform a complete forensic investigation of the QAT checkpoint architecture to discover the mathematical root cause of why QAT probabilities never exceed $0.733812$.

### Forensic Inspection of Quantized Layer `fc2`
We inspect the output linear operator of the serialized QAT checkpoint:
- In PyTorch quantized execution, the final linear layer (`fc2`) outputs an unsigned 8-bit quantized tensor (`torch.quint8`).
- An unsigned 8-bit integer is strictly bounded: $q \in [0, 255]$.
- The output operator records a static **quantization scale** $s$ and **zero-point** $z$.

Let us read the actual scale and zero-point parameters directly from the serialized checkpoint.
""")

    add_code(cells, r"""
# Forensic inspection of QAT output layer parameters
fc2_weight = model_qat.fc2.weight()
fc2_scale = float(model_qat.fc2.scale)
fc2_zero_point = int(model_qat.fc2.zero_point)

print("=== QAT Final Output Layer (fc2) Quantization Parameters ===")
print(f"Output Tensor Dtype:  {model_qat.fc2}")
print(f"Quantization Scale:   {fc2_scale:.17f}")
print(f"Zero-Point Offset:    {fc2_zero_point}")
print(f"Quantized Range:      q in [0, 255] (unsigned 8-bit integer)")

# Mathematical derivation of maximum logit and probability
q_max = 255
z_max = (q_max - fc2_zero_point) * fc2_scale
p_max = 1.0 / (1.0 + np.exp(-z_max))

print("\n=== Mathematical Derivation of Upper Bound ===")
print(f"Maximum Integer Code: q_max = {q_max}")
print(f"Maximum Logit:        z_max = (q_max - z) * s = ({q_max} - {fc2_zero_point}) * {fc2_scale:.8f} = {z_max:.7f}")
print(f"Maximum Probability:  p_max = sigma(z_max) = 1 / (1 + exp(-{z_max:.7f})) = {p_max:.8f}")
""")

    add_markdown(cells, r"""
### Mathematical Derivation of the QAT Output Ceiling
From first principles:
$$z_{\max} = (q_{\max} - z) \cdot s = (255 - 215) \times 0.025351248681545258 = 40 \times 0.025351248681545258 = +1.0140499$$

Applying the sigmoid activation function:
$$p_{\max} = \sigma(+1.0140499) = \frac{1}{1 + e^{-1.0140499}} = \mathbf{0.73381203}$$

No input tensor, no matter how strongly positive its features are, can ever produce a dequantized logit exceeding $+1.0140499$ or a probability exceeding $0.73381203$.

### Empirical Verification on 49,251 Test Flows
Below, we count the exact number of test flows clamped at this theoretical ceiling.
""")

    add_code(cells, r"""
# Empirical verification of ceiling saturation
max_prob_observed = float(np.max(qat_probs))
at_ceiling = np.isclose(qat_probs, p_max, atol=1e-6)
total_at_ceiling = int(np.sum(at_ceiling))
vpn_at_ceiling = int(np.sum(at_ceiling & (y_test == 1)))
nonvpn_at_ceiling = int(np.sum(at_ceiling & (y_test == 0)))
total_vpn = int(np.sum(y_test == 1))

print("=== Empirical Saturation Counts on Test Set (N=49,251) ===")
print(f"Theoretical Upper Ceiling:       {p_max:.8f}")
print(f"Maximum Observed QAT Probability: {max_prob_observed:.8f}")
print(f"Total Flows Clamped at Ceiling:   {total_at_ceiling:,d} ({total_at_ceiling/len(y_test)*100:.2f}%)")
print(f"VPN Flows Clamped at Ceiling:     {vpn_at_ceiling:,d} of {total_vpn:,d} ({vpn_at_ceiling/total_vpn*100:.2f}%)")
print(f"Non-VPN Flows Clamped at Ceiling: {nonvpn_at_ceiling:,d} of {len(y_test)-total_vpn:,d} ({nonvpn_at_ceiling/(len(y_test)-total_vpn)*100:.2f}%)")
print(f"Test Flows in range [0.74, 1.00]: {int(np.sum(qat_probs >= 0.74)):,d} (Strictly Zero)")

assert np.isclose(max_prob_observed, 0.73381203, atol=1e-5), "Max probability discrepancy!"
assert total_at_ceiling == 4070, f"Ceiling count discrepancy: expected 4,070, found {total_at_ceiling}"
assert vpn_at_ceiling == 2642, f"VPN ceiling count discrepancy: expected 2,642, found {vpn_at_ceiling}"
""")

    add_markdown(cells, r"""
### Figures 8 and 9: Visualizing Output Saturation
We plot class-conditional probability histograms and output logit distributions to highlight the representational ceiling.

**Figure 8. QAT predicted-probability distributions by true class, highlighting the output saturation ceiling.** VPN flows (red) pile up directly against the theoretical ceiling at $p=0.733812$, with 98.11% of VPN instances sharing this identical score.  
**Figure 9. Distribution of QAT logits or output scores, showing the representable output ceiling.** The right edge of the logit distribution terminates sharply at $+1.01405$, corresponding to the maximum integer code $q=255$ in the quantized linear operator.
""")

    add_code(cells, r"""
# Figure 8: QAT Probabilities by Class
fig, ax = plt.subplots(figsize=(8, 4.2))
ax.hist(qat_probs[y_test == 0], bins=50, range=(0, 0.8), color='#1f77b4', alpha=0.7, label='Non-VPN (Class 0)', log=True)
ax.hist(qat_probs[y_test == 1], bins=50, range=(0, 0.8), color='#d62728', alpha=0.7, label='VPN (Class 1)', log=True)
ax.axvline(p_max, color='black', linestyle='--', lw=1.8, label=f'Ceiling p_max = {p_max:.4f}')
ax.annotate(f"98.11% of VPN flows\nclamped here\n(N=2,642)", xy=(p_max, 2500), xytext=(0.50, 2000),
            arrowprops=dict(facecolor='black', arrowstyle='->', lw=1.5), fontsize=9,
            bbox=dict(boxstyle="round,pad=0.4", fc="#ffffff", ec="gray", alpha=0.9))
ax.set_xlabel('Predicted Probability')
ax.set_ylabel('Flow Count (Log Scale)')
ax.set_title('Figure 8. QAT predicted-probability distributions by true class, highlighting output saturation.', fontsize=10.5)
ax.legend(loc='upper center')
ax.grid(True, linestyle='--', alpha=0.3)
plt.tight_layout()
fig.savefig(os.path.join(figures_dir, "figure8_qat_probability_saturation.png"), dpi=300, bbox_inches='tight')
fig.savefig(os.path.join(figures_dir, "figure8_qat_probability_saturation.pdf"), bbox_inches='tight')
plt.show()

# Figure 9: QAT Logit Distribution
fig, ax = plt.subplots(figsize=(8, 4.2))
ax.hist(qat_cached_logits, bins=60, color='#2ca02c', alpha=0.75, edgecolor='black', lw=0.5, log=True)
ax.axvline(z_max, color='red', linestyle='--', lw=1.8, label=f'Logit Ceiling z_max = {z_max:.4f}')
ax.annotate(f"Maximum Representable Logit\n(q = 255)", xy=(z_max, 5000), xytext=(z_max - 2.5, 4000),
            arrowprops=dict(facecolor='red', arrowstyle='->', lw=1.5), fontsize=9,
            bbox=dict(boxstyle="round,pad=0.4", fc="#ffffff", ec="red", alpha=0.9))
ax.set_xlabel('Pre-Sigmoid Logit Output (z)')
ax.set_ylabel('Flow Count (Log Scale)')
ax.set_title('Figure 9. Distribution of QAT logits showing the representable output ceiling.', fontsize=10.5)
ax.legend(loc='upper left')
ax.grid(True, linestyle='--', alpha=0.3)
plt.tight_layout()
fig.savefig(os.path.join(figures_dir, "figure9_qat_logit_ceiling.png"), dpi=300, bbox_inches='tight')
fig.savefig(os.path.join(figures_dir, "figure9_qat_logit_ceiling.pdf"), bbox_inches='tight')
plt.show()
""")
