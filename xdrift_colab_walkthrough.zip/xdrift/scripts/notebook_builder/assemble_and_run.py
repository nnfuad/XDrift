"""Assemble and Execute the Complete XDrift A-to-Z Research Walkthrough Notebook."""

import os
import sys
import json
import time
import nbformat as nbf
from nbconvert.preprocessors import ExecutePreprocessor

# Ensure paths
script_dir = os.path.dirname(os.path.abspath(__file__))
xdrift_root = os.path.abspath(os.path.join(script_dir, "..", ".."))
sys.path.insert(0, xdrift_root)

from scripts.notebook_builder.part1_foundations import build_part1
from scripts.notebook_builder.part2_models_quantization import build_part2
from scripts.notebook_builder.part3_predictive_calibration import build_part3
from scripts.notebook_builder.part4_explainability_drift import build_part4
from scripts.notebook_builder.part5_clustered_hardware import build_part5
from scripts.notebook_builder.part6_limitations_reproducibility import build_part6

def main():
    print("=" * 80)
    print("      Building Complete XDrift A-to-Z Master Research Notebook      ")
    print("=" * 80)
    
    nb = nbf.v4.new_notebook()
    nb.metadata.kernelspec = {
        "display_name": "Python 3 (ipykernel)",
        "language": "python",
        "name": "python3"
    }
    nb.metadata.language_info = {
        "name": "python",
        "version": "3.12.7",
        "mimetype": "text/x-python",
        "codemirror_mode": {"name": "ipython", "version": 3},
        "pygments_lexer": "ipython3"
    }
    
    cells = []
    
    print("Assembling Part 1: Foundations (Sections 0, 1, 2, 3)...")
    build_part1(cells)
    
    print("Assembling Part 2: Models & Quantization (Sections 4, 5, 6, 7)...")
    build_part2(cells)
    
    print("Assembling Part 3: Predictive Performance & Calibration (Sections 8, 9, 10, 11)...")
    build_part3(cells)
    
    print("Assembling Part 4: Explainability, Drift & Subgroups (Sections 12, 13, 14, 15, 16)...")
    build_part4(cells)
    
    print("Assembling Part 5: Clustered Inference, Hardware & Hypotheses (Sections 17, 18, 19)...")
    build_part5(cells)
    
    print("Assembling Part 6: Limitations, Conclusions & Appendix (Sections 20, 21, 22)...")
    build_part6(cells)
    
    nb.cells = cells
    
    out_notebook_dir = os.path.join(xdrift_root, "notebooks")
    os.makedirs(out_notebook_dir, exist_ok=True)
    out_notebook_path = os.path.join(out_notebook_dir, "XDrift_A_to_Z_Research_Walkthrough.ipynb")
    
    # Count cell types
    md_count = sum(1 for c in cells if c.cell_type == 'markdown')
    code_count = sum(1 for c in cells if c.cell_type == 'code')
    print(f"\nAssembly Complete! Total Cells: {len(cells)} (Markdown: {md_count}, Code: {code_count})")
    
    with open(out_notebook_path, 'w', encoding='utf-8') as f:
        nbf.write(nb, f)
    print(f"Wrote unexecuted notebook to: {out_notebook_path}")
    
    print("\n" + "=" * 80)
    print("      Executing Notebook End-to-End via ExecutePreprocessor      ")
    print("=" * 80)
    
    ep = ExecutePreprocessor(timeout=900, kernel_name='python3')
    start_time = time.time()
    
    try:
        # Run in xdrift root so relative paths match
        ep.preprocess(nb, {'metadata': {'path': xdrift_root}})
        elapsed = time.time() - start_time
        print(f"\nExecution Succeeded in {elapsed:.2f} seconds!")
    except Exception as e:
        print(f"\nExecution Failed: {e}")
        # Save partial execution
        with open(out_notebook_path, 'w', encoding='utf-8') as f:
            nbf.write(nb, f)
        raise e
        
    with open(out_notebook_path, 'w', encoding='utf-8') as f:
        nbf.write(nb, f)
    print(f"Saved executed notebook with populated outputs to: {out_notebook_path}")
    
    # Audit cell outputs
    executed_code = 0
    failed_code = 0
    for i, cell in enumerate(nb.cells):
        if cell.cell_type == 'code':
            if cell.outputs:
                executed_code += 1
                for out in cell.outputs:
                    if out.output_type == 'error':
                        print(f"ERROR in Code Cell #{i+1}: {out.ename}: {out.evalue}")
                        failed_code += 1
            else:
                print(f"WARNING: Code Cell #{i+1} has no output!")
                
    print(f"\nOutput Audit: {executed_code}/{code_count} code cells executed successfully. Failed cells: {failed_code}")
    assert failed_code == 0, f"Found {failed_code} failed code cells in executed notebook!"
    
    # Check figures directory
    figs_dir = os.path.join(out_notebook_dir, "figures")
    figs = os.listdir(figs_dir)
    png_figs = [f for f in figs if f.endswith('.png')]
    pdf_figs = [f for f in figs if f.endswith('.pdf')]
    print(f"\nGenerated Figures in {figs_dir}:")
    print(f"  PNG Figures: {len(png_figs)} / 19")
    print(f"  PDF Figures: {len(pdf_figs)} / 19")
    
    print("\nNotebook generation and full execution completed successfully!")

if __name__ == "__main__":
    main()
