"""Part 5: Clustered Inference, Hardware Benchmarks, and Hypothesis Matrix."""

from .helpers import add_markdown, add_code

def build_part5(cells):
    # =========================================================================
    # SECTION 17: Clustered Statistical Inference Across Canonical Groups
    # =========================================================================
    add_markdown(cells, r"""
---
## Section 17: Clustered Statistical Inference Across Canonical Session Groups

### What We Are Investigating
The test partition contains 49,251 flows, but they originate from only **16 independent canonical session groups**. Standard statistical tests (such as unadjusted t-tests) assume observations are identically and independently distributed ($i.i.d.$), which radically underestimates variance when flows within the same session share correlated packet dynamics. 

We implement **Cluster-Resampled Bootstrap Inference** across the 16 canonical groups to account for session dependence.

### Delineation of Two Distinct Estimands
When evaluating the mean logit shift between FP32 and PTQ ($\Delta z = z_{\text{PTQ}} - z_{\text{FP32}}$), we must distinguish two scientifically different estimands:
1. **Estimand A: Flow-Weighted Cluster Mean**:
   $$\theta_A = \frac{\sum_{g=1}^G \sum_{i \in g} \Delta z_{g, i}}{\sum_{g=1}^G N_g}$$
   - **Research Question**: *"What is the expected logit shift for an arbitrary flow drawn randomly from this specific test pool?"*
   - Each flow carries equal weight ($1/N$). Consequently, large sessions dominate: `skype_audio3` (39,179 flows) contributes **79.55%** of the total weight.
2. **Estimand B: Group-Unweighted Mean of Session-Group Means**:
   $$\theta_B = \frac{1}{G} \sum_{g=1}^G \bar{\Delta z}_g$$
   - **Research Question**: *"What is the expected logit shift for an arbitrary future network capture session?"*
   - Each session group carries equal weight ($1/G = 1/16$), regardless of whether it contains 14 flows or 39,179 flows.
""")

    add_code(cells, r"""
from src.statistics.paired_inference import group_cluster_bootstrap_ci

# Extract capture IDs and compute logit differences
test_caps = test_npz['capture_ids']
delta_z = ptq_cached_logits - fp32_cached_logits

# Compute group statistics across the 16 canonical groups
canonical_test_groups = [get_session_group(str(c)) for c in test_caps]
unique_groups, group_counts = np.unique(canonical_test_groups, return_counts=True)

# Sort by flow count descending
sort_order = np.argsort(group_counts)[::-1]
unique_groups = unique_groups[sort_order]
group_counts = group_counts[sort_order]

print("=== Test Partition Canonical Session Groups (K=16) ===")
print(f"{'Canonical Group Name':<28} | {'Type':<8} | {'Flow Count':<12} | {'% of Test':<10} | {'Mean Delta z':<12}")
print("-" * 80)

group_means = {}
for g, cnt in zip(unique_groups, group_counts):
    g_mask = (np.array(canonical_test_groups) == g)
    g_mean = float(np.mean(delta_z[g_mask]))
    group_means[g] = g_mean
    is_vpn = "VPN" if g.startswith("vpn_") else "Non-VPN"
    pct = (cnt / len(delta_z)) * 100.0
    print(f"{g:<28} | {is_vpn:<8} | {cnt:>12,d} | {pct:>9.2f}% | {g_mean:>+11.4f}")

# Execute cluster bootstrap for Estimand A and Estimand B (10,000 bootstrap iterations)
boot_res = group_cluster_bootstrap_ci(delta_z, np.array(canonical_test_groups), n_boot=10000, seed=42, map_canonical=False)

print("\n=== Cluster Bootstrap Results across 16 Canonical Groups (B=10,000) ===")
print(f"Estimand A (Flow-Weighted Cluster Mean):")
print(f"  Point Estimate: {boot_res['mean_flow_weighted']:+.6f}")
print(f"  95% Bootstrap CI: [{boot_res['ci_lower_flow_weighted']:+.6f}, {boot_res['ci_upper_flow_weighted']:+.6f}] (Spans Zero)")
print(f"Estimand B (Group-Unweighted Mean of Means):")
print(f"  Point Estimate: {boot_res['mean_group_unweighted']:+.6f}")
print(f"  95% Bootstrap CI: [{boot_res['ci_lower_group_unweighted']:+.6f}, {boot_res['ci_upper_group_unweighted']:+.6f}] (Strictly Positive)")
""")

    add_markdown(cells, r"""
### Plain-Language Interpretation: Why Estimands A and B Disagree
- **Estimand A is negative ($-0.0778$, CI $[-0.1130, +0.3275]$)**: Out of 16 groups, only 3 groups have negative mean logit shifts (`skype_audio3`, `email1`, and `vpn_bittorrent`). However, because `skype_audio3` contains 39,179 flows, its negative shift ($-0.1164$) drags the flow-weighted average below zero.
- **Estimand B is positive ($+0.2270$, CI $[+0.0639, +0.3562]$)**: Thirteen out of 16 groups (81.25%) exhibit positive mean logit shifts (ranging up to $+0.5262$). When every session is treated as an equal independent experimental unit, the mean shift is unambiguously positive and statistically significant.

### Leave-One-Group-Out Sensitivity Analysis
To confirm the outsized leverage of `skype_audio3`, we compute the flow-weighted mean shift when each of the 16 groups is omitted in turn.
""")

    add_code(cells, r"""
# Leave-One-Group-Out Sensitivity Analysis
loo_estimates = []
for g in unique_groups:
    omit_mask = (np.array(canonical_test_groups) != g)
    loo_mean = float(np.mean(delta_z[omit_mask]))
    loo_estimates.append((g, loo_mean))

print("=== Leave-One-Group-Out Sensitivity Analysis (Flow-Weighted Mean) ===")
print(f"All 16 Groups (Full Test Set): Point Estimate = {np.mean(delta_z):+.6f}")
for g, val in loo_estimates[:5]:
    cnt = int(np.sum(np.array(canonical_test_groups) == g))
    print(f"  Omit '{g:<20}' (N={cnt:>5,d}): Shift = {val:+.6f}")

# Excluding skype_audio3 cluster bootstrap
non_skype_mask = (np.array(canonical_test_groups) != 'skype_audio3')
boot_sens = group_cluster_bootstrap_ci(delta_z[non_skype_mask], np.array(canonical_test_groups)[non_skype_mask], 
                                       n_boot=10000, seed=42, map_canonical=False)

print(f"\nSensitivity Test (15 Groups, Excluding 'skype_audio3'):")
print(f"  Estimand A Point Estimate: {boot_sens['mean_flow_weighted']:+.6f}")
print(f"  Estimand A 95% CI:         [{boot_sens['ci_lower_flow_weighted']:+.6f}, {boot_sens['ci_upper_flow_weighted']:+.6f}]")
""")

    add_markdown(cells, r"""
### Figures 14, 15, and 16: Group Shifts, Bootstrap Distribution, and Sensitivity
We visualize group logit shifts, the bimodal cluster bootstrap distribution, and the leave-one-group-out sensitivity analysis.

**Figure 14. Mean logit shift by canonical session group, with group sizes displayed.** Thirteen of 16 groups exhibit positive shifts, while the single largest group (`skype_audio3`, 39,179 flows) exhibits a negative shift.  
**Figure 15. Flow-weighted cluster-bootstrap distribution, highlighting its asymmetry and relationship to the largest capture group.** The bimodal distribution reflects whether `skype_audio3` is sampled in a given bootstrap replicate.  
**Figure 16. Leave-one-group-out sensitivity analysis for the flow-weighted mean logit shift.** Omission of `skype_audio3` flips the point estimate from $-0.0778$ to $+0.0720$.
""")

    add_code(cells, r"""
# Figure 14: Group Mean Logit Shifts Bar Chart
fig, ax = plt.subplots(figsize=(11, 4.5))
y_pos = np.arange(len(unique_groups))
colors = ['#d62728' if g.startswith('vpn_') else '#1f77b4' for g in unique_groups]
bar_widths = [group_means[g] for g in unique_groups]

bars = ax.barh(y_pos, bar_widths, color=colors, alpha=0.85, edgecolor='black', lw=0.5)
ax.axvline(0, color='black', lw=1.2)
ax.set_yticks(y_pos)
ax.set_yticklabels([f"{g} (N={cnt:,d})" for g, cnt in zip(unique_groups, group_counts)], fontsize=8)
ax.invert_yaxis()
ax.set_xlabel('Mean Logit Shift (PTQ - FP32)')
ax.set_title('Figure 14. Mean logit shift by canonical session group, with group sizes displayed.', fontsize=10.5)
ax.grid(True, linestyle='--', alpha=0.3)

# Add custom legend
from matplotlib.patches import Patch
legend_elements = [Patch(facecolor='#1f77b4', edgecolor='black', label='Non-VPN Session Group'),
                   Patch(facecolor='#d62728', edgecolor='black', label='VPN Session Group')]
ax.legend(handles=legend_elements, loc='lower right', fontsize=8.5)

plt.tight_layout()
fig.savefig(os.path.join(figures_dir, "figure14_group_logit_shifts.png"), dpi=300, bbox_inches='tight')
fig.savefig(os.path.join(figures_dir, "figure14_group_logit_shifts.pdf"), bbox_inches='tight')
plt.show()

# Figure 15 & 16: Cluster Bootstrap Distribution and LOO Sensitivity
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.2))

# Subplot 1: Cluster Bootstrap Replicates (recompute 2000 replicates for fast plotting)
rng = np.random.RandomState(42)
boot_means_flow = []
for _ in range(2000):
    resamp = rng.choice(unique_groups, size=len(unique_groups), replace=True)
    tot_sum = sum(group_means[g] * int(np.sum(np.array(canonical_test_groups) == g)) for g in resamp)
    tot_cnt = sum(int(np.sum(np.array(canonical_test_groups) == g)) for g in resamp)
    boot_means_flow.append(tot_sum / tot_cnt)

ax1.hist(boot_means_flow, bins=35, color='#8e44ad', alpha=0.75, edgecolor='black', lw=0.5)
ax1.axvline(np.mean(delta_z), color='red', linestyle='--', lw=1.8, label=f'Full Sample Mean = {np.mean(delta_z):.4f}')
ax1.axvline(0.0, color='black', linestyle='-', lw=1.2)
ax1.set_xlabel('Flow-Weighted Mean Shift across Replicates')
ax1.set_ylabel('Bootstrap Replicate Count')
ax1.set_title('(a) Cluster Bootstrap Distribution (Bimodal)', fontsize=10)
ax1.legend(fontsize=8.5)
ax1.grid(True, linestyle='--', alpha=0.3)

# Subplot 2: Leave-One-Group-Out Sensitivity
loo_names = [x[0] for x in loo_estimates]
loo_vals = [x[1] for x in loo_estimates]
y_idx = np.arange(len(loo_names))

ax2.scatter(loo_vals, y_idx, color='#e67e22', s=45, zorder=3)
ax2.axvline(np.mean(delta_z), color='red', linestyle='--', lw=1.5, label=f'Baseline (-0.0778)')
ax2.axvline(0.0, color='black', linestyle='-', lw=1.0)
ax2.set_yticks(y_idx)
ax2.set_yticklabels(loo_names, fontsize=8)
ax2.invert_yaxis()
ax2.set_xlabel('Flow-Weighted Shift when Group is Omitted')
ax2.set_title('(b) Leave-One-Group-Out Sensitivity', fontsize=10)
ax2.legend(fontsize=8.5)
ax2.grid(True, linestyle='--', alpha=0.3)

plt.tight_layout()
fig.savefig(os.path.join(figures_dir, "figure15_cluster_bootstrap_distribution.png"), dpi=300, bbox_inches='tight')
fig.savefig(os.path.join(figures_dir, "figure15_cluster_bootstrap_distribution.pdf"), bbox_inches='tight')
fig.savefig(os.path.join(figures_dir, "figure16_leave_one_group_out.png"), dpi=300, bbox_inches='tight')
fig.savefig(os.path.join(figures_dir, "figure16_leave_one_group_out.pdf"), bbox_inches='tight')
plt.show()
""")

    # =========================================================================
    # SECTION 18: Hardware Performance and Model Size
    # =========================================================================
    add_markdown(cells, r"""
---
## Section 18: Hardware Performance and Model Size

### What We Are Investigating
Edge deployments require strict adherence to memory footprints, energy budgets, and throughput targets. We evaluate single-flow latency (Batch Size = 1) versus batched throughput (Batch Size = 64) and calculate checkpoint compression ratios.

### Latency vs Throughput: A Critical Distinction
- **Streaming Latency (Batch Size = 1)**: Measures the elapsed time from the arrival of an individual flow's 64th packet to the completion of the classifier forward pass. Essential for real-time firewall inline packet-drop decisions.
- **Batched Throughput (Batch Size = 64)**: Measures the total number of flows classified per second when amortized across hardware vector registers. Essential for offline PCAP forensic triage and central gateway monitoring.
""")

    add_code(cells, r"""
# Load authoritative hardware benchmark metrics
hw_path = os.path.join(project_root, "results/metrics/hardware_benchmarks.json")
with open(hw_path, 'r') as f:
    hw_data = json.load(f)

bs1 = hw_data['latency_edge_bs1']
bs64 = hw_data['latency_batched_bs64']
sizes = hw_data['artifact_sizes']

print("=== Table 3: Hardware Latency and Throughput Benchmarks (Apple Silicon ARM64, QNNPACK) ===")
print(f"{'Batch Size':<10} | {'Model':<6} | {'Median Latency (ms)':<20} | {'Mean Latency (ms)':<18} | {'Throughput (flows/s)':<22} | {'Speedup'}")
print("-" * 92)
print(f"{'1 (Stream)':<10} | {'FP32':<6} | {bs1['fp32']['median_latency_ms']:>19.3f} | {bs1['fp32']['mean_latency_ms']:>17.3f} | {bs1['fp32']['throughput_samples_per_sec']:>21.1f} | {'Baseline'}")
print(f"{'1 (Stream)':<10} | {'PTQ':<6} | {bs1['ptq']['median_latency_ms']:>19.3f} | {bs1['ptq']['mean_latency_ms']:>17.3f} | {bs1['ptq']['throughput_samples_per_sec']:>21.1f} | {bs1['median_latency_speedup_ptq']:.2f}x")
print(f"{'1 (Stream)':<10} | {'QAT':<6} | {bs1['qat']['median_latency_ms']:>19.3f} | {bs1['qat']['mean_latency_ms']:>17.3f} | {bs1['qat']['throughput_samples_per_sec']:>21.1f} | {bs1['median_latency_speedup_qat']:.2f}x")
print("-" * 92)
print(f"{'64 (Batch)':<10} | {'FP32':<6} | {bs64['fp32']['median_latency_ms']:>19.3f} | {bs64['fp32']['mean_latency_ms']:>17.3f} | {bs64['fp32']['throughput_samples_per_sec']:>21.1f} | {'Baseline'}")
print(f"{'64 (Batch)':<10} | {'PTQ':<6} | {bs64['ptq']['median_latency_ms']:>19.3f} | {bs64['ptq']['mean_latency_ms']:>17.3f} | {bs64['ptq']['throughput_samples_per_sec']:>21.1f} | {bs64['median_latency_speedup_ptq']:.2f}x")
print(f"{'64 (Batch)':<10} | {'QAT':<6} | {bs64['qat']['median_latency_ms']:>19.3f} | {bs64['qat']['mean_latency_ms']:>17.3f} | {bs64['qat']['throughput_samples_per_sec']:>21.1f} | {bs64['median_latency_speedup_qat']:.2f}x")

print("\n=== Checkpoint Size and Compression Ratios ===")
fp32_bytes = sizes['fp32_bytes']
ptq_bytes = sizes['ptq_bytes']
qat_bytes = sizes['qat_bytes']

print(f"FP32 Checkpoint Size: {fp32_bytes:,d} bytes ({fp32_bytes/1024:.1f} KB)")
print(f"PTQ  Checkpoint Size: {ptq_bytes:,d} bytes ({ptq_bytes/1024:.1f} KB) -> Compression Ratio: {fp32_bytes/ptq_bytes:.2f}x")
print(f"QAT  Checkpoint Size: {qat_bytes:,d} bytes ({qat_bytes/1024:.1f} KB) -> Compression Ratio: {fp32_bytes/qat_bytes:.2f}x")
""")

    add_markdown(cells, r"""
### Plain-Language Interpretation: Why Batch Size Governs Speedup
- **Streaming Latency (Batch Size = 1)**: Quantization yields modest speedups ($1.05\times$ for PTQ, $1.10\times$ for QAT). At batch size 1, memory transfer latency and Python/PyTorch runtime operator dispatch overhead dominate execution time; the arithmetic units spend substantial time idle between invocations.
- **Batched Throughput (Batch Size = 64)**: Quantization yields massive speedups (**$11.94\times$ throughput speedup** for PTQ, **$12.44\times$ median latency speedup**). When batched, QNNPACK utilizes ARM NEON 8-bit vector instructions to execute four times as many multiply-accumulate operations per cycle while fitting working tensors entirely within on-chip L1/L2 caches.

### Figures 17, 18, and 19: Hardware Benchmark Visualizations
We plot latency, throughput, and checkpoint sizes.

**Figure 17. Median inference latency by model and batch size.** Single-flow latency decreases modestly from $0.267$ ms to $0.255$ ms, while batched latency plummets from $9.503$ ms to $0.764$ ms.  
**Figure 18. Inference throughput by model and batch size.** INT8 quantization accelerates batched throughput from $6,387$ to $76,265$ flows/second ($11.94\times$ speedup).  
**Figure 19. Checkpoint-size comparison for FP32, PTQ, and QAT.** INT8 representation compresses model storage from $188.7$ KB to $53.0$ KB ($3.56\times$ reduction).
""")

    add_code(cells, r"""
# Figure 17, 18, 19: Hardware Benchmarks
fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(12, 4.0))

# Subplot 1: Latency Comparison
x = np.array([0, 1])
width = 0.25
models_labels = ['FP32', 'PTQ', 'QAT']
colors = ['#1f77b4', '#ff7f0e', '#2ca02c']

bs1_lats = [bs1['fp32']['median_latency_ms'], bs1['ptq']['median_latency_ms'], bs1['qat']['median_latency_ms']]
bs64_lats = [bs64['fp32']['median_latency_ms'], bs64['ptq']['median_latency_ms'], bs64['qat']['median_latency_ms']]

for i, (m, c) in enumerate(zip(models_labels, colors)):
    ax1.bar(x + (i - 1) * width, [bs1_lats[i], bs64_lats[i]], width, label=m, color=c, alpha=0.85)

ax1.set_xticks(x)
ax1.set_xticklabels(['BS = 1 (Stream)', 'BS = 64 (Batch)'])
ax1.set_ylabel('Median Latency (ms, Log Scale)')
ax1.set_yscale('log')
ax1.set_title('(a) Median Latency', fontsize=10)
ax1.legend(fontsize=8.5)
ax1.grid(True, linestyle='--', alpha=0.3)

# Subplot 2: Throughput Comparison
bs1_tps = [bs1['fp32']['throughput_samples_per_sec'], bs1['ptq']['throughput_samples_per_sec'], bs1['qat']['throughput_samples_per_sec']]
bs64_tps = [bs64['fp32']['throughput_samples_per_sec'], bs64['ptq']['throughput_samples_per_sec'], bs64['qat']['throughput_samples_per_sec']]

for i, (m, c) in enumerate(zip(models_labels, colors)):
    ax2.bar(x + (i - 1) * width, [bs1_tps[i], bs64_tps[i]], width, label=m, color=c, alpha=0.85)

ax2.set_xticks(x)
ax2.set_xticklabels(['BS = 1 (Stream)', 'BS = 64 (Batch)'])
ax2.set_ylabel('Throughput (flows/sec, Log Scale)')
ax2.set_yscale('log')
ax2.set_title('(b) Inference Throughput', fontsize=10)
ax2.legend(fontsize=8.5)
ax2.grid(True, linestyle='--', alpha=0.3)

# Subplot 3: Checkpoint Size Comparison
ckpt_sizes_kb = [fp32_bytes / 1024.0, ptq_bytes / 1024.0, qat_bytes / 1024.0]
ax3.bar(models_labels, ckpt_sizes_kb, color=colors, alpha=0.85, edgecolor='black', lw=0.5)
ax3.set_ylabel('Checkpoint File Size (KB)')
ax3.set_title('(c) Storage Footprint', fontsize=10)
ax3.grid(True, linestyle='--', alpha=0.3)

for i, v in enumerate(ckpt_sizes_kb):
    ax3.annotate(f"{v:.1f} KB\n({fp32_bytes/ptq_bytes:.2f}x)" if i > 0 else f"{v:.1f} KB",
                 xy=(i, v), xytext=(0, 3), textcoords="offset points", ha='center', fontsize=8.5)

plt.tight_layout()
fig.savefig(os.path.join(figures_dir, "figure17_inference_latency.png"), dpi=300, bbox_inches='tight')
fig.savefig(os.path.join(figures_dir, "figure17_inference_latency.pdf"), bbox_inches='tight')
fig.savefig(os.path.join(figures_dir, "figure18_inference_throughput.png"), dpi=300, bbox_inches='tight')
fig.savefig(os.path.join(figures_dir, "figure18_inference_throughput.pdf"), bbox_inches='tight')
fig.savefig(os.path.join(figures_dir, "figure19_checkpoint_sizes.png"), dpi=300, bbox_inches='tight')
fig.savefig(os.path.join(figures_dir, "figure19_checkpoint_sizes.pdf"), bbox_inches='tight')
plt.show()
""")

    # =========================================================================
    # SECTION 19: Research Findings and Hypothesis Assessment Matrix
    # =========================================================================
    add_markdown(cells, r"""
---
## Section 19: Research Findings and Hypothesis Assessment Matrix

### Consolidated Scientific Evaluation
We synthesize the experimental outcomes across all research dimensions into a structured hypothesis assessment table:

| Hypothesis / Research Question | Primary Experiment | Observed Quantitative Result | Supporting Evidence | Methodological Limitations | Final Verdict |
|:---|:---|:---|:---|:---|:---|
| **H1: Predictive Performance Preservation** | Held-out test evaluation on 49,251 flows across 16 canonical groups. | $F_1 = 0.7746$ (FP32), $0.7697$ (PTQ), $0.7762$ (QAT). ROC-AUC: $0.9796 \to 0.9834$. | Validation-calibrated thresholds preserve precision ($64.12\%$) and recall ($98.33\%$). | Requires threshold re-tuning for QAT ($\tau=0.680$). Reused $\tau=0.900$ yields $F_1=0.0$. | **SUPPORTED** |
| **H2: PTQ Attribution Invariance** | Paired Wilcoxon signed-rank test on $\Delta \text{TV}$ vs explainer noise ($N=100$). | Wilcoxon $W=1506.0$, $p=0.000459$. Positive rank sum $R^+=3544.0 > R^-=1506.0$. Median $\Delta \text{TV} = +0.0049$. | 69% of flows exhibit positive drift relative to multi-seed noise baseline. | Top features remain stable ($IoU_5=0.9786$, 95% identical top-5). | **DETECTABLE SHIFT (Equivalence Rejected)** |
| **H3: QAT Structural Restructuring** | Multi-metric attribution comparison on 100-flow test cohort. | Signed cosine collapses to $0.4830$. TV distance surges to $0.2346$. Top-5 Jaccard drops to $0.9553$. | STE fine-tuning updates model weights into alternative parameter basins. | Limited to 100-flow cohort and 150-eval KernelSHAP budget. | **SUPPORTED** |
| **H4: Class-Conditional Drift Heterogeneity** | Subgroup stratification by true traffic class (VPN $n=50$ vs Non-VPN $n=50$). | Non-VPN flows exhibit significantly higher TV drift than VPN ($p = 1.13 \times 10^{-7}$). | Mann-Whitney $U=480.0$ (PTQ), $U=278.0$ (QAT). Rank-biserial $r_{rb} = +0.6160$. | Disagreement subgroup non-estimable (0 cohort disagreements). Limited test VPN session diversity ($K_{\text{vpn}}=3$). | **PARTIALLY SUPPORTED** |
""")
