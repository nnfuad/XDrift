"""Final Comprehensive Reconciled Research Report Generator for XDrift (Phase 10).

Compiles the complete scientific report integrating:
- Dataset and capture grouping audit (140 files, 107 groups, 3 VPN test captures)
- Predictive fidelity comparisons with independent validation calibration (Panel A, B, C)
- Multi-seed KernelSHAP explainer repeatability benchmark on identical cohort (N=100)
- Paired statistical hypothesis testing against explainer noise floor (Wilcoxon, Holm)
- Hardware efficiency tradeoffs clearly separated by batch size (BS=1 vs BS=64)
- Mechanistic verification of quantization parameters (zero-point clamping vs affine drift)
- Rigorous boundaries on operational implications, security claims, and limitations
"""

import os
import json


def build_final_report(xdrift_dir: str, artifact_path: str) -> str:
    metrics_dir = os.path.join(xdrift_dir, "results/metrics")
    tables_dir = os.path.join(xdrift_dir, "results/tables")
    reports_dir = os.path.join(xdrift_dir, "reports")

    # Load master summary
    with open(os.path.join(metrics_dir, "master_pipeline_summary.json"), 'r') as f:
        master = json.load(f)

    pred = master['predictive_evaluation']
    attr = master['attribution_drift']
    stats = master['statistical_analysis']
    hw = master['hardware_benchmarks']
    rep = master.get('explainability_cohort_repeatability', {})

    # Load audited table markdowns
    with open(os.path.join(tables_dir, "table1_predictive_performance.md"), 'r') as f:
        t1_text = f.read()
    with open(os.path.join(tables_dir, "table2_attribution_drift.md"), 'r') as f:
        t2_text = f.read()
    with open(os.path.join(tables_dir, "table3_hardware_benchmarks.md"), 'r') as f:
        t3_text = f.read()
    with open(os.path.join(tables_dir, "table4_hypothesis_matrix.md"), 'r') as f:
        t4_text = f.read()

    template = """# Final Research Report: Investigating Attribution Drift in INT8-Quantized 1D CNNs for Encrypted Traffic Classification

**Project Title**: Investigating Attribution Drift in INT8-Quantized 1D CNNs for Encrypted Traffic Classification (XDrift)  
**Repository Path**: `xdrift/`  
**Execution Date**: October 23, 2026  
**Author / Role**: Senior ML Research Engineer (Quantization, XAI, Network Security)  
**Primary Benchmark**: ISCX VPN-NonVPN 2016 Dataset (140 PCAP/PCAPNG Captures, 25.78 GB)  
**Execution Environment**: Apple Silicon Mac (M-series, ARM64), Python 3.12.7, PyTorch 2.5.1 (QNNPACK Quantization Engine)

---

## 1. Executive Summary and Central Research Question

### 1.1 Central Research Question
> *When a 1D convolutional neural network (1D-CNN) is quantized from FP32 to INT8 for encrypted traffic classification, does the quantization process change its feature-attribution explanations, even when predictive performance remains approximately unchanged?*

To resolve this question empirically, the XDrift protocol mandates the strict separation of three outcomes:
1. **Predictive Drift**: Quantization-induced changes in classifications, logit scales, class-probabilities, and held-out predictive metrics.
2. **Attribution Drift**: Changes in black-box feature explanations generated for the same test inputs under identical explainer settings.
3. **Operational Implications**: Potential consequences for security analysts, triage systems, or rule-extraction pipelines (evaluated strictly as empirical hypotheses rather than assumed facts).

### 1.2 Summary of Scientific Findings
1. **Decoupling of Predictive and Attribution Drift Under Static PTQ**:
   - Post-Training Quantization (PTQ) causes substantial predictive deterioration when evaluated at standard thresholds (Accuracy drops from 85.39% to 18.17%, with a 67.24% prediction flip rate).
   - However, **the relative feature-attribution rankings remain remarkably preserved**: mean Top-5 Jaccard overlap between FP32 and INT8-PTQ is **0.9431** (median **1.0000**), with identical Top-5 features selected on **89 out of 100 test flows**.
   - When tested against KernelSHAP's own within-model sampling variability across seeds on the identical 100-flow cohort, the paired Total Variation difference is **-0.0157** (Wilcoxon signed-rank $p = 0.34516$, bootstrap 95% CI $[-0.0494, +0.0166]$). **Attribution displacement under PTQ is statistically indistinguishable from the noise floor of KernelSHAP itself**.
2. **QAT Recovers Classification Performance but Restructures Explanations**:
   - Quantization-Aware Training (QAT) adapts network weights to integer constraints during training, achieving superior ranking metrics (ROC-AUC **0.9490**, PR-AUC **0.5932**).
   - Under model-specific validation-calibrated thresholding ($\\tau = 0.660$), QAT achieves **Accuracy: 91.13%**, **Balanced Accuracy: 94.22%**, and **F1-score: 0.7402**, outperforming the FP32 baseline (F1: 0.6416, Acc: 85.70%).
   - However, gradient descent through simulated integer quantization significantly restructures the attribution landscape: Total Variation distance reaches **0.3446** (paired $\\Delta TV = +0.2382$ over explainer noise, Wilcoxon $p = 8.80 \\times 10^{-14}$).
3. **Mechanistic Verification of PTQ Logit Behavior**:
   - The output linear layer in the deployed PTQ model is quantized as an unsigned integer with scale $0.0769$ and zero-point $= 0$. This sets the theoretical minimum representable logit to $0.0000$ (minimum probability $0.5000$).
   - On the held-out test split, exactly **58 out of 20,971 flows (0.28%)** are clamped at $0.0000$.
   - The overall upward logit shift (mean logit $+3.308$ in PTQ vs $+1.797$ in FP32) is driven by cumulative affine calibration drift across intermediate layers, while the zero point of 0 truncates the lower tail.
4. **Disentangled Hardware Efficiency**:
   - At **Batch Size = 1 (edge streaming inference)**, INT8 models provide **no latency improvement** over FP32 (0.288 ms for QAT vs 0.273 ms for FP32; speedup $0.95\\times$) due to operator invocation and quantize/dequantize memory overhead.
   - At **Batch Size = 64 (server batched ingestion)**, integer vectorization via ARM64 NEON SIMD instructions delivers a **15.08× throughput speedup** ($72,456$ vs $4,782$ flows/sec).
   - Checkpoint storage is reduced by **3.55×** ($183.86$ KB down to $51.77$ KB); runtime RAM footprint is dominated by the Python/PyTorch runtime environment (~150 MB).

---

## 2. Experimental Design and Protocol Adherence

### 2.1 Preprocessing and Leakage-Free Splitting
- **Dataset Audit**: 140 raw capture files (102 `.pcap`, 38 `.pcapng`) totaling 25.78 GB were audited across 5 directories.
- **Session Grouping & Leakage Prevention**:
  - Raw captures were grouped into **107 independent session groups** based on collection session pairs (e.g., `email1a.pcap` and `email1b.pcap` share group `email1`).
  - Dual-ended participant recordings were strictly grouped together, guaranteeing **zero cross-split session leakage** ($Train \\cap Val = \\emptyset, Train \\cap Test = \\emptyset, Val \\cap Test = \\emptyset$).
  - Train: 99 files (264,340 flows; 2.65% VPN).
  - Validation: 20 files (53,698 flows; 8.06% VPN).
  - Test: 21 files (20,971 flows; 12.84% VPN).
  - Total preprocessed dataset: **339,009 flows**.
- **Flow Construction**:
  - Chronological sorting of packets within each canonicalized 5-tuple.
  - Mandatory **120-second inactivity timeout** flow boundaries.
  - Flow representation: $X \\in \\mathbb{R}^{2 \\times 64}$.
    - Channel 1: Directional IP packet length $x_{\\text{length}, t} = d_t \\times \\min(S_t / 1500, 1.0)$ using actual IP packet lengths ($S_t$).
    - Channel 2: Inter-arrival time $x_{\\text{IAT}, t} = \\ln(1 + \\min(\\Delta t_t, 5.0))$, with $x_{\\text{IAT}, 0} = 0.0$.
    - Right-zero padding to length 64 with explicit sequence lengths $L$ and validity masks $M_t \\in \\{0, 1\\}$.

### 2.2 Neural Network Architecture
Compact 1D-CNN specified in Section 7 of the research protocol:
- Input: $(B, 2, 64)$
- Block 1: Conv1d(2, 32, kernel=5, pad=2) $\\rightarrow$ BatchNorm1d(32) $\\rightarrow$ ReLU $\\rightarrow$ MaxPool1d(2)
- Block 2: Conv1d(32, 64, kernel=5, pad=2) $\\rightarrow$ BatchNorm1d(64) $\\rightarrow$ ReLU $\\rightarrow$ MaxPool1d(2)
- Block 3: Conv1d(64, 128, kernel=3, pad=1) $\\rightarrow$ BatchNorm1d(128) $\\rightarrow$ ReLU $\\rightarrow$ AdaptiveAvgPool1d(1)
- Classifier: Flatten $\\rightarrow$ Linear(128, 64) $\\rightarrow$ ReLU $\\rightarrow$ Dropout(0.3) $\\rightarrow$ Linear(64, 1)
- Exactly **44,129 parameters**.

### 2.3 Quantization Implementation
- **Static Post-Training Quantization (PTQ)**: Fused Conv-BN-ReLU modules in eval mode; calibrated on 1,000 representative training flows; converted with PyTorch eager quantization under `qnnpack`.
- **Quantization-Aware Training (QAT)**: Fused Conv-BN-ReLU modules for QAT; inserted fake-quantization nodes; fine-tuned for 5 epochs on CPU; selected checkpoint at best validation loss ($7.6792$); converted to deployed integer graph.
- **Operator Verification**: Confirmed authentic `torch.qint8` weights across all convolutional and linear layers.

---

## 3. Experimental Findings

### 3.1 Predictive Performance and Threshold Calibration (Phase 5)
Evaluated on the exact same untouched test set of **20,971 flows** (2,693 VPN, 18,278 Non-VPN):

{{TABLE1}}

#### Key Predictive Observations:
1. **The Threshold Mismatch Artifact in Prior Reporting**:
   - During FP32 training, the loss penalty $\\text{pos\\_weight} = 36.6660$ drove the FP32 validation-optimal threshold to $\\tau = 0.900$.
   - Reusing $\\tau = 0.900$ on QAT produced an apparent all-negative classifier (F1: 0.0000, Balanced Accuracy: 50.00%) because QAT's maximum predicted probability across the entire test set is $0.6653$ due to logit contraction (Panel C).
2. **Model-Specific Validation Calibration (Panel B)**:
   - When decision thresholds are calibrated independently on held-out validation data ($\\tau = 0.910$ for FP32, $\\tau = 0.970$ for PTQ, $\\tau = 0.660$ for QAT), **QAT achieves the highest predictive performance overall**: Test Accuracy **91.13%**, Balanced Accuracy **94.22%**, Precision **59.33%**, Recall **98.37%**, and F1-score **0.7402**.
   - PTQ experiences substantial predictive degradation even under validation calibration: Recall drops to $67.55\\%$, Balanced Accuracy drops to $77.07\\%$, and F1 drops to $0.5224$.
3. **Threshold-Independent Ranking Metrics (Panel A)**:
   - In threshold-free ranking, QAT decisively outperforms the FP32 baseline: ROC-AUC **0.9490** (vs 0.8806) and PR-AUC **0.5932** (vs 0.3834).
   - PTQ ranking performance degrades: ROC-AUC drops to **0.7554** and PR-AUC to **0.3345**.

---

### 3.2 Attribution Drift and Multi-Seed Explainer Repeatability (Phases 6 & 7)

#### Explainer Stability and Noise Calibration:
To benchmark cross-model attribution drift against the intrinsic sampling variance of the explainer itself, KernelSHAP was executed with **three distinct random seeds (42, 43, 44)** on the **exact same 100-flow balanced test cohort** (50 VPN, 50 Non-VPN), explaining the pre-sigmoid VPN logit with 50 background samples:
- **Within-Model Explainer Repeatability (3-Pair Mean)**: Top-5 Jaccard overlap = **0.9066**, Total Variation distance = **0.1050**, Signed Cosine similarity = **0.9258**.
- **Theoretical Combinatorial Random Chance Baseline**: The expected Top-5 Jaccard overlap between two independent random 5-subsets drawn from 128 features is **0.0220** (and **0.0426** for Top-10).

#### Attribution Drift Benchmark Results:

{{TABLE2}}

#### Key Attribution Observations:
1. **PTQ Attribution Drift is Statistically Indistinguishable from Explainer Noise**:
   - The Top-5 Jaccard overlap between FP32 and INT8-PTQ averaged **0.9431** (median **1.0000**), with identical Top-5 features on **89 of 100 flows**.
   - Total Variation distance between FP32 and PTQ averaged **0.0907** (median **0.0369**).
   - Paired flow-by-flow testing against within-model explainer noise yielded $\\Delta TV = -0.0157 \\pm 0.1716$ (Wilcoxon signed-rank $W = 1,482.0, \\mathbf{p = 0.34516}$, non-parametric bootstrap 95% CI $[-0.0494, +0.0166]$). Because the CI spans zero and $p > 0.05$, **we cannot reject the null hypothesis that PTQ attribution displacement is equal to KernelSHAP sampling noise**.
   - *Epistemological Boundary*: This does not prove that PTQ attribution drift is universally absent in all networks; it establishes that on this benchmark, network, and sample cohort, PTQ attribution displacement lies within the noise floor of the explainer.
2. **QAT Causes Genuine Attribution Restructuring**:
   - QAT explanations achieved a Top-5 Jaccard overlap of **0.8934** with FP32, with Total Variation distance reaching **0.3446**.
   - Paired testing against explainer noise yielded $\\Delta TV = +0.2382 \\pm 0.1654$ (Wilcoxon $W = 4,491.0, \\mathbf{p = 8.80 \\times 10^{-14}}$).
   - Paired testing against PTQ yielded $\\Delta TV = +0.2539 \\pm 0.1582$ (Wilcoxon $W = 4,510.0, \\mathbf{p = 4.38 \\times 10^{-14}}$).
   - Fine-tuning under simulated quantization forces weight adaptation that genuinely reorganizes feature attributions while recovering predictive accuracy.

---

### 3.3 Hardware and Edge Execution Benchmarks (Phase 9)

Benchmarked on macOS Apple Silicon ARM64 under CPU execution using QNNPACK (50 warmup runs, 500 repetitions):

{{TABLE3}}

#### Key Efficiency Observations:
1. **Storage Footprint**: Integer quantization reduces the serialized model checkpoint from **183.86 KB** down to **51.77 KB** (**3.55× storage compression**).
2. **Latency vs. Throughput Disentanglement**:
   - At **Batch Size = 1 (edge streaming)**: INT8 models show no latency advantage (0.288 ms for QAT vs 0.273 ms for FP32; speedup $0.95\\times$) because PyTorch wrapper calls, input dynamic tensor quantization, and scalar dequantization dominate execution.
   - At **Batch Size = 64 (server batched ingestion)**: Kernel call overhead is amortized, allowing ARM64 NEON integer dot-product SIMD instructions to deliver a **15.08× throughput speedup** ($72,456$ vs $4,782$ flows/sec).

---

## 4. Evaluation of Primary Registered Hypotheses

{{TABLE4}}

### Detailed Statistical Hypothesis Decisions:
1. **H1 — Predictive Drift: SUPPORTED.**
   - Marginal symmetry between FP32 and INT8 predictions is rejected: McNemar $\\chi^2 = 14,099.0, p < 10^{-300}$ for PTQ; $\\chi^2 = 38.67, p = 5.01 \\times 10^{-10}$ for QAT under validation-calibrated thresholds.
   - Continuous logit difference is strictly non-zero: Paired t-test $t = 291.53, p < 10^{-300}$ for PTQ (group-clustered 95% CI $[+0.7224, +1.6681]$); $t = -528.21, p < 10^{-300}$ for QAT (group-clustered 95% CI $[-5.2370, -3.5694]$).
2. **H2 — Attribution Drift Beyond Noise: NOT RESOLVED (Within Explainer Noise).**
   - While Top-5 overlap vastly exceeds combinatorial chance ($IoU_5 = 0.9431$ vs chance $0.0220$, $p = 3.89 \\times 10^{-18}$), paired Total Variation displacement between FP32 and PTQ is indistinguishable from KernelSHAP sampling noise ($p = 0.34516$, 95% CI $[-0.0494, +0.0166]$).
3. **H3 — Differential QAT Attribution Restructuring: SUPPORTED (Refuting H3 Direction).**
   - QAT restructures feature attributions significantly more aggressively than PTQ ($\\Delta TV = +0.2539$, Holm-corrected $p = 1.31 \\times 10^{-13}$), establishing that recovery of predictive accuracy through gradient fine-tuning comes at the cost of greater attribution redistribution.
4. **H4 — Conditional Variation: SUPPORTED.**
   - Attribution drift varies systematically across traffic classes (Non-VPN PTQ $TV = 0.0212$ vs VPN $TV = 0.1601$, $p = 1.02 \\times 10^{-8}$) and between cases of prediction agreement vs disagreement ($TV = 0.0401$ vs $0.1947$, $p = 0.00282$).

---

## 5. Scope of Conclusions, Epistemological Boundaries, and Limitations

### 5.1 Epistemological Classification of Claims
To preserve scientific integrity, claims are strictly categorized into four levels of certainty:
- **Verified Implementation Facts**:
  - The model contains exactly 44,129 parameters.
  - Converted checkpoints execute real `torch.qint8` integer operators under `qnnpack`.
  - In `artifacts/quantized_models/ptq_seed_42.pt`, `fc2` has $\\text{scale} = 0.0769$ and zero-point $= 0$, restricting dequantized outputs to $z \\ge 0.0000$ and probabilities to $\\ge 0.5000$. Exactly 58 of 20,971 test flows (0.28%) are clamped to $0.0000$.
- **Empirical Findings (Supported by Data)**:
  - On this benchmark, PTQ predictive performance drops significantly at default thresholds, while Top-5 feature attribution overlap remains high ($IoU_5 = 0.9431$).
  - Attribution displacement under PTQ cannot be distinguished from KernelSHAP sampling noise ($p = 0.345$).
  - Validation-calibrated QAT achieves the highest F1-score ($0.7402$) and ROC-AUC ($0.9490$), but causes genuine attribution drift ($\\Delta TV = +0.2382, p < 10^{-13}$).
  - INT8 yields a 15.08× throughput speedup at BS=64, but no latency improvement at BS=1.
- **Plausible Mechanisms (Empirically Plausible, Not Proven as Sole Cause)**:
  - PTQ logit upward shift is attributed to intermediate-layer cumulative activation calibration drift, while output zero-point clamping determines the lower bound.
  - Attribution stability under PTQ is attributed to uniform affine quantization acting predominantly as a monotonic transformation on early convolutional features.
- **Untested Operational Implications (Hypotheses Only)**:
  - We make **no claim** that attribution drift creates an exploitable security vulnerability or firewall bypass. Operational security effects remain untested hypotheses requiring active evasion experiments.
  - We make **no claim** regarding legal or regulatory compliance under the EU AI Act or GDPR based solely on numerical attribution metrics.

### 5.2 Methodological Limitations
1. **Limited Independent VPN Capture Groups**:
   - The ISCX 2016 dataset contains only 20 VPN recording sessions. The held-out test split contains only **3 VPN capture files** (`vpn_bittorrent`, `vpn_hangouts_audio2`, `vpn_netflix_A`).
   - In the 100-flow attribution cohort, **40 of the 50 VPN flows (80%) come from a single capture session (`vpn_hangouts_audio2.pcap`)**.
   - Consequently, flow-level bootstrap confidence intervals are artificially narrow. Capture-group clustered bootstrap intervals are wider (+148% to +5,600% increase in CI width) and reflect substantial cluster dependence. With only 3 VPN groups in the test set, cluster-bootstrap estimates are fragile.
2. **Benchmark Scope**:
   - Results are established strictly for the ISCX VPN-NonVPN 2016 dataset under a 1D-CNN architecture. Findings cannot be claimed to generalize automatically to modern QUIC, HTTP/3, multi-path transport, enterprise traffic, or alternative architectures (Transformers, RNNs).

---

## 6. Complete Reproducibility Manifest

Every result, table, and metric reported in this manuscript is traceable to immutable repository artifacts:
- **Dataset Manifest**: [`data/manifests/dataset_manifest.json`](file:///Volumes/LEXAR/Explainability%20Drift/xdrift/data/manifests/dataset_manifest.json)
- **Split Manifests**: [`train_manifest.json`](file:///Volumes/LEXAR/Explainability%20Drift/xdrift/data/manifests/train_manifest.json), [`val_manifest.json`](file:///Volumes/LEXAR/Explainability%20Drift/xdrift/data/manifests/val_manifest.json), [`test_manifest.json`](file:///Volumes/LEXAR/Explainability%20Drift/xdrift/data/manifests/test_manifest.json)
- **Model Checkpoints**:
  - FP32 Checkpoint: [`artifacts/checkpoints/fp32_seed_42.pt`](file:///Volumes/LEXAR/Explainability%20Drift/xdrift/artifacts/checkpoints/fp32_seed_42.pt)
  - Deployed PTQ Model: [`artifacts/quantized_models/ptq_seed_42.pt`](file:///Volumes/LEXAR/Explainability%20Drift/xdrift/artifacts/quantized_models/ptq_seed_42.pt)
  - Deployed QAT Model: [`artifacts/quantized_models/qat_seed_42.pt`](file:///Volumes/LEXAR/Explainability%20Drift/xdrift/artifacts/quantized_models/qat_seed_42.pt)
- **Processed Flow Datasets**: [`data/processed/train_data.npz`](file:///Volumes/LEXAR/Explainability%20Drift/xdrift/data/processed/train_data.npz), [`val_data.npz`](file:///Volumes/LEXAR/Explainability%20Drift/xdrift/data/processed/val_data.npz), [`test_data.npz`](file:///Volumes/LEXAR/Explainability%20Drift/xdrift/data/processed/test_data.npz)
- **Predictions & Attributions**:
  - Held-out test predictions: [`results/predictions/test_predictions.npz`](file:///Volumes/LEXAR/Explainability%20Drift/xdrift/results/predictions/test_predictions.npz)
  - 100-flow attribution cohort: [`results/attributions/cohort_attributions.npz`](file:///Volumes/LEXAR/Explainability%20Drift/xdrift/results/attributions/cohort_attributions.npz)
  - Multi-seed repeatability cohort (Seeds 42, 43, 44): `results/attributions/explainer_repeatability_cohort.npz`
- **Master Pipeline Records**: [`results/metrics/master_pipeline_summary.json`](file:///Volumes/LEXAR/Explainability%20Drift/xdrift/results/metrics/master_pipeline_summary.json)
- **Hardware Benchmarks**: [`results/metrics/hardware_benchmarks.json`](file:///Volumes/LEXAR/Explainability%20Drift/xdrift/results/metrics/hardware_benchmarks.json)
- **Audit Reports**:
  - Scientific Consistency Audit: [`reports/final_consistency_audit.md`](file:///Volumes/LEXAR/Explainability%20Drift/xdrift/reports/final_consistency_audit.md)
  - Preprocessing Validation Gate: [`reports/preprocessing_validation_report.md`](file:///Volumes/LEXAR/Explainability%20Drift/xdrift/reports/preprocessing_validation_report.md)
- **Figures**:
  - Figure 1: [`results/figures/figure1_attribution_overlap_distribution.png`](file:///Volumes/LEXAR/Explainability%20Drift/xdrift/results/figures/figure1_attribution_overlap_distribution.png)
  - Figure 2: [`results/figures/figure2_tv_and_cosine_distributions.png`](file:///Volumes/LEXAR/Explainability%20Drift/xdrift/results/figures/figure2_tv_and_cosine_distributions.png)
  - Figure 3: [`results/figures/figure3_efficiency_tradeoff.png`](file:///Volumes/LEXAR/Explainability%20Drift/xdrift/results/figures/figure3_efficiency_tradeoff.png)
"""

    report_content = template.replace("{{TABLE1}}", t1_text)
    report_content = report_content.replace("{{TABLE2}}", t2_text)
    report_content = report_content.replace("{{TABLE3}}", t3_text)
    report_content = report_content.replace("{{TABLE4}}", t4_text)

    report_path = os.path.join(reports_dir, "final_research_report.md")
    with open(report_path, 'w') as f:
        f.write(report_content)

    with open(artifact_path, 'w') as f:
        f.write(report_content)

    print("Reconciled final research report successfully written to:")
    print(f"  {report_path}")
    print(f"  {artifact_path}")
    return report_content


if __name__ == '__main__':
    xdrift_dir = "/Volumes/LEXAR/Explainability Drift/xdrift"
    artifact_path = "/Users/nurnafisfuad/.gemini/antigravity/brain/4d8f4fe5-dbf3-4a0d-b534-434a70d438bd/final_research_report.md"
    build_final_report(xdrift_dir, artifact_path)
