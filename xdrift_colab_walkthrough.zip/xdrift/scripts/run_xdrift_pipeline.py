"""Master XDrift Pipeline Execution Script (Phases 5 through 9).

Executes:
- Phase 5: Held-out Predictive Evaluation across FP32, PTQ, and QAT
- Phase 6: Explainability Pilot (runtime, stability, and budget determination)
- Phase 7: Full Attribution Evaluation (Top-k Jaccard, Spearman, TV, Cosine, Temporal)
- Phase 8: Statistical Inference (Paired Bootstrap, Group-Clustered Bootstrap, Wilcoxon, Holm)
- Phase 9: Hardware & Latency Benchmarks (Artifact size, BS=1 & BS=64 latency)
"""

import os
import time
import json
import argparse
from typing import Dict, List, Any

import numpy as np
import torch

from src.evaluation.evaluate_models import evaluate_all_models, load_int8_model
from src.models.cnn1d import Compact1DCNN
from src.training.train import load_dataset
from src.explainability.kernel_shap import (
    sample_background_dataset,
    explain_single_model,
    compute_pairwise_drift_metrics,
    flatten_tensor_to_features
)
from src.statistics.paired_inference import (
    paired_bootstrap_ci,
    group_cluster_bootstrap_ci,
    compute_paired_effect_sizes,
    apply_holm_correction
)
from src.evaluation.benchmark_hardware import benchmark_all_models


def run_full_pipeline(
    train_npz: str,
    test_npz: str,
    fp32_ckpt: str,
    ptq_model: str,
    qat_model: str,
    output_base_dir: str,
    cohort_size: int = 100,
    shap_nsamples: int = 150,
    background_samples: int = 50,
    explainer_seed: int = 42
) -> Dict[str, Any]:
    print("\n=======================================================")
    print("      XDrift Master Pipeline Execution (Phases 5-9)    ")
    print("=======================================================")

    results = {}

    # -------------------------------------------------------------------------
    # PHASE 5: Predictive Comparison on Untouched Test Split
    # -------------------------------------------------------------------------
    print("\n--- Phase 5: Predictive Evaluation ---")
    eval_summary = evaluate_all_models(
        test_npz_path=test_npz,
        fp32_checkpoint_path=fp32_ckpt,
        ptq_model_path=ptq_model,
        qat_model_path=qat_model,
        results_dir=os.path.join(output_base_dir, "results")
    )
    results['predictive_evaluation'] = eval_summary

    # -------------------------------------------------------------------------
    # PHASE 6: Explainability Pilot
    # -------------------------------------------------------------------------
    print("\n--- Phase 6: Explainability Pilot & Stability Benchmark ---")
    X_train, _, y_train_t, _, _ = load_dataset(train_npz)
    X_test, masks_test, y_test_t, flow_ids_test, capture_ids_test = load_dataset(test_npz)
    y_test = y_test_t.numpy().flatten().astype(int)
    y_train = y_train_t.numpy().flatten().astype(int)

    # Sample representative background from training set
    bg_matrix = sample_background_dataset(
        X_train.numpy(), y_train, n_samples=background_samples, seed=explainer_seed
    )

    # Select pilot cohort: 10 VPN, 10 Non-VPN instances
    rng = np.random.RandomState(explainer_seed)
    idx_vpn_test = np.where(y_test == 1)[0]
    idx_nonvpn_test = np.where(y_test == 0)[0]

    n_pilot_half = 10
    pilot_vpn = rng.choice(idx_vpn_test, size=min(n_pilot_half, len(idx_vpn_test)), replace=False)
    pilot_nonvpn = rng.choice(idx_nonvpn_test, size=min(n_pilot_half, len(idx_nonvpn_test)), replace=False)
    pilot_idx = np.concatenate([pilot_vpn, pilot_nonvpn])

    pilot_tensors = X_test[pilot_idx].numpy()
    pilot_matrix = flatten_tensor_to_features(pilot_tensors)
    pilot_masks = masks_test[pilot_idx].numpy()

    # Load models for explainability
    fp32_model = Compact1DCNN().eval()
    fp32_model.load_state_dict(torch.load(fp32_ckpt, map_location='cpu')['state_dict'])

    int8_ptq = load_int8_model(ptq_model)
    int8_qat = load_int8_model(qat_model)

    print(f"Running Pilot KernelSHAP on {len(pilot_idx)} instances (budget={shap_nsamples})...")
    t0_pilot = time.time()
    phi_fp32_p1, dur_fp32 = explain_single_model(fp32_model, bg_matrix, pilot_matrix, nsamples=shap_nsamples, seed=explainer_seed)
    # Stability test: second run with different seed (seed + 1) on same model
    phi_fp32_p2, _ = explain_single_model(fp32_model, bg_matrix, pilot_matrix, nsamples=shap_nsamples, seed=explainer_seed + 1)
    phi_ptq_p1, dur_ptq = explain_single_model(int8_ptq, bg_matrix, pilot_matrix, nsamples=shap_nsamples, seed=explainer_seed)
    pilot_time = time.time() - t0_pilot

    # Measure explainer noise (within-model agreement across seeds)
    noise_drift = compute_pairwise_drift_metrics(phi_fp32_p1, phi_fp32_p2, pilot_masks)
    # Measure quantization drift on pilot
    pilot_quant_drift = compute_pairwise_drift_metrics(phi_fp32_p1, phi_ptq_p1, pilot_masks)

    pilot_summary = {
        'pilot_instances': len(pilot_idx),
        'pilot_duration_seconds': round(pilot_time, 2),
        'seconds_per_explanation': round(dur_fp32 / len(pilot_idx), 3),
        'within_model_explainer_noise': {
            'top5_jaccard_mean': noise_drift['top5_jaccard']['mean'],
            'spearman_mean': noise_drift['spearman_correlation']['mean'],
            'tv_mean': noise_drift['total_variation_distance']['mean'],
            'cosine_mean': noise_drift['signed_cosine_similarity']['mean']
        },
        'between_model_quant_drift': {
            'top5_jaccard_mean': pilot_quant_drift['top5_jaccard']['mean'],
            'spearman_mean': pilot_quant_drift['spearman_correlation']['mean'],
            'tv_mean': pilot_quant_drift['total_variation_distance']['mean'],
            'cosine_mean': pilot_quant_drift['signed_cosine_similarity']['mean']
        }
    }
    results['explainability_pilot'] = pilot_summary
    print(f"Pilot completed in {pilot_time:.2f}s ({pilot_summary['seconds_per_explanation']}s/expl).")
    print(f"  Within-Model Explainer Jaccard (Noise Baseline): {pilot_summary['within_model_explainer_noise']['top5_jaccard_mean']:.4f}")
    print(f"  Between-Model PTQ Drift Jaccard:                {pilot_summary['between_model_quant_drift']['top5_jaccard_mean']:.4f}")

    # -------------------------------------------------------------------------
    # PHASE 7: Full Attribution Evaluation
    # -------------------------------------------------------------------------
    print(f"\n--- Phase 7: Full Attribution Evaluation (Cohort N={cohort_size}) ---")
    # Sample balanced test cohort
    n_vpn_target = cohort_size // 2
    n_nonvpn_target = cohort_size - n_vpn_target

    sampled_vpn = rng.choice(idx_vpn_test, size=min(n_vpn_target, len(idx_vpn_test)), replace=False)
    sampled_nonvpn = rng.choice(idx_nonvpn_test, size=min(n_nonvpn_target, len(idx_nonvpn_test)), replace=False)
    cohort_idx = np.concatenate([sampled_vpn, sampled_nonvpn])
    rng.shuffle(cohort_idx)

    cohort_tensors = X_test[cohort_idx].numpy()
    cohort_matrix = flatten_tensor_to_features(cohort_tensors)
    cohort_masks = masks_test[cohort_idx].numpy()
    cohort_y = y_test[cohort_idx]
    cohort_flow_ids = flow_ids_test[cohort_idx]
    cohort_capture_ids = capture_ids_test[cohort_idx]

    # Predict outputs for subgroup analysis
    fp32_pred_logits = eval_summary['fp32_metrics']
    test_preds = np.load(os.path.join(output_base_dir, "results/predictions/test_predictions.npz"))
    fp32_c_preds = test_preds['fp32_preds'][cohort_idx]
    ptq_c_preds = test_preds['ptq_preds'][cohort_idx]
    qat_c_preds = test_preds['qat_preds'][cohort_idx] if 'qat_preds' in test_preds else None

    agreement_ptq = fp32_c_preds == ptq_c_preds
    disagreement_ptq = ~agreement_ptq

    print(f"Extracting explanations for Cohort N={len(cohort_idx)} ({np.sum(cohort_y==1)} VPN, {np.sum(cohort_y==0)} Non-VPN)...")
    t0_expl = time.time()
    phi_fp32, dur_fp32_full = explain_single_model(fp32_model, bg_matrix, cohort_matrix, nsamples=shap_nsamples, seed=explainer_seed)
    phi_ptq, dur_ptq_full = explain_single_model(int8_ptq, bg_matrix, cohort_matrix, nsamples=shap_nsamples, seed=explainer_seed)
    phi_qat, dur_qat_full = explain_single_model(int8_qat, bg_matrix, cohort_matrix, nsamples=shap_nsamples, seed=explainer_seed)
    total_expl_time = time.time() - t0_expl
    print(f"Attributions computed in {total_expl_time:.2f}s.")

    # Save raw attribution matrices
    attr_dir = os.path.join(output_base_dir, "results/attributions")
    os.makedirs(attr_dir, exist_ok=True)
    np.savez_compressed(
        os.path.join(attr_dir, "cohort_attributions.npz"),
        phi_fp32=phi_fp32,
        phi_ptq=phi_ptq,
        phi_qat=phi_qat,
        masks=cohort_masks,
        y=cohort_y,
        flow_ids=cohort_flow_ids,
        capture_ids=cohort_capture_ids
    )

    # Compute attribution drift metrics
    drift_ptq = compute_pairwise_drift_metrics(phi_fp32, phi_ptq, cohort_masks)
    drift_qat = compute_pairwise_drift_metrics(phi_fp32, phi_qat, cohort_masks)
    drift_ptq_qat = compute_pairwise_drift_metrics(phi_ptq, phi_qat, cohort_masks)

    # Subgroups
    subgroups = {
        'all': drift_ptq,
        'vpn_only': compute_pairwise_drift_metrics(phi_fp32[cohort_y==1], phi_ptq[cohort_y==1], cohort_masks[cohort_y==1]),
        'nonvpn_only': compute_pairwise_drift_metrics(phi_fp32[cohort_y==0], phi_ptq[cohort_y==0], cohort_masks[cohort_y==0]),
        'prediction_agree': compute_pairwise_drift_metrics(phi_fp32[agreement_ptq], phi_ptq[agreement_ptq], cohort_masks[agreement_ptq]) if np.sum(agreement_ptq) > 0 else {},
        'prediction_disagree': compute_pairwise_drift_metrics(phi_fp32[disagreement_ptq], phi_ptq[disagreement_ptq], cohort_masks[disagreement_ptq]) if np.sum(disagreement_ptq) > 0 else {}
    }

    results['attribution_drift'] = {
        'fp32_vs_ptq': drift_ptq,
        'fp32_vs_qat': drift_qat,
        'ptq_vs_qat': drift_ptq_qat,
        'subgroups_ptq': {k: {m: v[m] for m in ['top5_jaccard', 'spearman_correlation', 'total_variation_distance', 'signed_cosine_similarity'] if m in v} for k, v in subgroups.items() if v}
    }

    # -------------------------------------------------------------------------
    # PHASE 8: Statistical Analysis
    # -------------------------------------------------------------------------
    print("\n--- Phase 8: Statistical Analysis & Hypothesis Testing ---")
    # Paired attribution metrics differences vs Random Chance
    iou5_arr = np.array(drift_ptq['per_instance']['top5_jaccard'])
    rand_base = drift_ptq['random_baseline_k5']
    iou_diff_from_chance = iou5_arr - rand_base

    # 1. Flow-level Paired Bootstrap
    boot_ci = paired_bootstrap_ci(iou5_arr)
    # 2. Group-Clustered Bootstrap by capture session
    cluster_ci = group_cluster_bootstrap_ci(iou5_arr, cohort_capture_ids)

    # Effect sizes and Wilcoxon test
    effect_sizes = compute_paired_effect_sizes(iou5_arr - pilot_summary['within_model_explainer_noise']['top5_jaccard_mean'])

    # Secondary comparisons tests (Wilcoxon tests)
    qat_iou5_arr = np.array(drift_qat['per_instance']['top5_jaccard'])
    p_vals = []
    # Test 1: PTQ overlap vs Explainer Noise
    eff_ptq = compute_paired_effect_sizes(iou5_arr - pilot_summary['within_model_explainer_noise']['top5_jaccard_mean'])
    p_vals.append(eff_ptq['wilcoxon_pvalue'])
    # Test 2: QAT overlap vs PTQ overlap
    eff_qat_ptq = compute_paired_effect_sizes(qat_iou5_arr - iou5_arr)
    p_vals.append(eff_qat_ptq['wilcoxon_pvalue'])
    # Test 3: TV distance PTQ vs QAT
    tv_ptq = np.array(drift_ptq['per_instance']['total_variation'])
    tv_qat = np.array(drift_qat['per_instance']['total_variation'])
    eff_tv = compute_paired_effect_sizes(tv_ptq - tv_qat)
    p_vals.append(eff_tv['wilcoxon_pvalue'])

    clean_pvals = [p if np.isfinite(p) else 1.0 for p in p_vals]
    corrected_pvals = apply_holm_correction(clean_pvals)

    stats_summary = {
        'primary_metric_top5_jaccard': {
            'observed_mean': boot_ci['mean'],
            'observed_median': boot_ci['median'],
            'bootstrap_95ci_flow_level': [boot_ci['ci_lower'], boot_ci['ci_upper']],
            'bootstrap_95ci_group_clustered': [cluster_ci['ci_lower'], cluster_ci['ci_upper']],
            'capture_groups_in_cohort': cluster_ci.get('groups', 0),
            'random_chance_baseline': rand_base,
            'explainer_noise_baseline': pilot_summary['within_model_explainer_noise']['top5_jaccard_mean']
        },
        'effect_sizes_ptq_vs_noise': {
            'cohens_d': effect_sizes['cohens_d'],
            'wilcoxon_r': effect_sizes['wilcoxon_r'],
            'raw_pvalue': effect_sizes['wilcoxon_pvalue'],
            'holm_corrected_pvalue': corrected_pvals[0]
        },
        'comparison_qat_vs_ptq': {
            'qat_top5_jaccard_mean': drift_qat['top5_jaccard']['mean'],
            'ptq_top5_jaccard_mean': drift_ptq['top5_jaccard']['mean'],
            'delta_jaccard': drift_qat['top5_jaccard']['mean'] - drift_ptq['top5_jaccard']['mean'],
            'raw_pvalue': eff_qat_ptq['wilcoxon_pvalue'],
            'holm_corrected_pvalue': corrected_pvals[1]
        }
    }
    results['statistical_analysis'] = stats_summary

    # -------------------------------------------------------------------------
    # PHASE 9: Hardware & Latency Benchmarks
    # -------------------------------------------------------------------------
    print("\n--- Phase 9: Hardware Benchmarks ---")
    hw_benchmarks = benchmark_all_models(
        fp32_checkpoint_path=fp32_ckpt,
        ptq_model_path=ptq_model,
        qat_model_path=qat_model,
        output_path=os.path.join(output_base_dir, "results/metrics/hardware_benchmarks.json")
    )
    results['hardware_benchmarks'] = hw_benchmarks

    # Save comprehensive master execution results
    master_file = os.path.join(output_base_dir, "results/metrics/master_pipeline_summary.json")
    with open(master_file, 'w') as f:
        json.dump(results, f, indent=2)

    print(f"\n=======================================================")
    print(f"  All Phases (5-9) Completed Successfully!")
    print(f"  Master Summary Saved to: {master_file}")
    print(f"=======================================================\n")
    return results


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Run XDrift Master Pipeline")
    parser.add_argument('--train_npz', type=str, default="/Volumes/LEXAR/Explainability Drift/xdrift/data/processed/train_data.npz")
    parser.add_argument('--test_npz', type=str, default="/Volumes/LEXAR/Explainability Drift/xdrift/data/processed/test_data.npz")
    parser.add_argument('--fp32_ckpt', type=str, default="/Volumes/LEXAR/Explainability Drift/xdrift/artifacts/checkpoints/fp32_seed_42.pt")
    parser.add_argument('--ptq_model', type=str, default="/Volumes/LEXAR/Explainability Drift/xdrift/artifacts/quantized_models/ptq_seed_42.pt")
    parser.add_argument('--qat_model', type=str, default="/Volumes/LEXAR/Explainability Drift/xdrift/artifacts/quantized_models/qat_seed_42.pt")
    parser.add_argument('--output_dir', type=str, default="/Volumes/LEXAR/Explainability Drift/xdrift")
    parser.add_argument('--cohort_size', type=int, default=100)
    parser.add_argument('--shap_nsamples', type=int, default=150)
    args = parser.parse_args()

    run_full_pipeline(
        train_npz=args.train_npz,
        test_npz=args.test_npz,
        fp32_ckpt=args.fp32_ckpt,
        ptq_model=args.ptq_model,
        qat_model=args.qat_model,
        output_base_dir=args.output_dir,
        cohort_size=args.cohort_size,
        shap_nsamples=args.shap_nsamples
    )
