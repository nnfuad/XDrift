"""Representative Preprocessing Pilot Script for XDrift Validation Gate (Step 3 & 4).

Selects representative files from both classes (VPN, Non-VPN),
both file formats (.pcap, .pcapng), and various link layers (Ethernet, DLT 101),
runs flow extraction, records comprehensive packet/flow audit metrics,
validates output NPZs, and computes runtime estimates.
"""

import os
import json
import time
from typing import Dict, List, Any
import numpy as np

from src.features.flow_extractor import extract_flows_from_pcap
from src.data.leakage_free_split import get_session_group


def run_pilot(manifest_dir: str, raw_base_dir: str, output_dir: str) -> Dict[str, Any]:
    # Load all manifests
    splits = ['train', 'val', 'test']
    split_manifests = {}
    for s in splits:
        with open(os.path.join(manifest_dir, f"{s}_manifest.json"), 'r') as f:
            split_manifests[s] = json.load(f)

    # Select representative files from each split:
    # We want:
    # Train: NonVPN .pcap, NonVPN .pcapng, VPN .pcap (DLT 101), VPN .pcap (DLT 1)
    # Val: NonVPN .pcap, NonVPN .pcapng, VPN .pcap
    # Test: NonVPN .pcap, NonVPN .pcapng, VPN .pcap
    selected_files = []

    for s, data in split_manifests.items():
        recs = data['files']
        # Non-VPN pcap
        nv_pcap = [r for r in recs if r['label'] == 0 and r['format'] == 'pcap']
        # Non-VPN pcapng
        nv_ng = [r for r in recs if r['label'] == 0 and r['format'] == 'pcapng']
        # VPN pcap
        v_pcap = [r for r in recs if r['label'] == 1]

        if nv_pcap:
            selected_files.append((s, nv_pcap[0]))
        if nv_ng:
            selected_files.append((s, nv_ng[0]))
        if v_pcap:
            selected_files.append((s, v_pcap[0]))

    print(f"Selected {len(selected_files)} representative capture files across splits:")
    for s, rec in selected_files:
        print(f"  [{s.upper()}] {rec['filename']} (Format: {rec['format']}, Label: {rec['label_name']})")

    os.makedirs(output_dir, exist_ok=True)

    pilot_audit_records = []
    split_tensors = {s: [] for s in splits}
    split_masks = {s: [] for s in splits}
    split_seqlens = {s: [] for s in splits}
    split_labels = {s: [] for s in splits}
    split_flow_ids = {s: [] for s in splits}
    split_capture_ids = {s: [] for s in splits}

    total_bytes_processed = 0
    t0_global = time.time()

    for s, rec in selected_files:
        full_path = os.path.join(raw_base_dir, rec['relative_path'])
        fsize = os.path.getsize(full_path)
        total_bytes_processed += fsize

        t0_file = time.time()
        res = extract_flows_from_pcap(full_path)
        t1_file = time.time()
        duration = t1_file - t0_file

        records = res['records']
        audit = res['audit']

        seq_lens = [r['seq_len'] for r in records]

        file_stat = {
            'filename': rec['filename'],
            'split': s,
            'format': rec['format'],
            'label': rec['label'],
            'label_name': rec['label_name'],
            'session_group': get_session_group(rec['filename']),
            'file_size_mb': round(fsize / (1024 * 1024), 2),
            'duration_seconds': round(duration, 3),
            'total_packets': audit['total_packets'],
            'accepted_packets': audit['accepted_packets'],
            'rejected_packets': audit['rejected_packets'],
            'rejected_non_ip': audit['rejected_non_ip'],
            'rejected_non_transport': audit['rejected_non_transport'],
            'flows_generated': len(records),
            'seq_len_mean': float(np.mean(seq_lens)) if seq_lens else 0.0,
            'seq_len_median': float(np.median(seq_lens)) if seq_lens else 0.0,
            'seq_len_min': int(np.min(seq_lens)) if seq_lens else 0,
            'seq_len_max': int(np.max(seq_lens)) if seq_lens else 0,
            'error': audit.get('error')
        }
        pilot_audit_records.append(file_stat)

        for r in records:
            split_tensors[s].append(r['tensor'])
            split_masks[s].append(r['mask'])
            split_seqlens[s].append(r['seq_len'])
            split_labels[s].append(rec['label'])
            split_flow_ids[s].append(r['flow_id'])
            split_capture_ids[s].append(r['capture_id'])

    t1_global = time.time()
    total_duration = t1_global - t0_global

    # Save NPZ files for each split
    npz_paths = {}
    validation_checks = {}

    for s in splits:
        if len(split_tensors[s]) == 0:
            continue
        X = np.stack(split_tensors[s], axis=0).astype(np.float32)
        masks = np.stack(split_masks[s], axis=0).astype(np.float32)
        seqlens = np.array(split_seqlens[s], dtype=np.int32)
        labels = np.array(split_labels[s], dtype=np.int64)
        flow_ids = np.array(split_flow_ids[s], dtype=object)
        capture_ids = np.array(split_capture_ids[s], dtype=object)

        out_path = os.path.join(output_dir, f"{s}_pilot.npz")
        np.savez_compressed(
            out_path,
            X=X,
            masks=masks,
            seq_lens=seqlens,
            y=labels,
            flow_ids=flow_ids,
            capture_ids=capture_ids
        )
        npz_paths[s] = out_path

        # Perform deep validation checks on saved NPZ
        loaded = np.load(out_path, allow_pickle=True)
        l_X = loaded['X']
        l_masks = loaded['masks']
        l_seqlens = loaded['seq_lens']
        l_y = loaded['y']
        l_flows = loaded['flow_ids']
        l_caps = loaded['capture_ids']

        val_check = {
            'shape_X': list(l_X.shape),
            'dtype_X': str(l_X.dtype),
            'has_nan_X': bool(np.isnan(l_X).any()),
            'has_inf_X': bool(np.isinf(l_X).any()),
            'channel1_min': float(np.min(l_X[:, 0, :])),
            'channel1_max': float(np.max(l_X[:, 0, :])),
            'channel2_min': float(np.min(l_X[:, 1, :])),
            'channel2_max': float(np.max(l_X[:, 1, :])),
            'shape_masks': list(l_masks.shape),
            'mask_sum_matches_seqlens': bool(np.all(np.sum(l_masks, axis=1) == l_seqlens)),
            'padding_is_strictly_zero': bool(
                np.all(l_X[:, 0, :][l_masks == 0] == 0.0) and
                np.all(l_X[:, 1, :][l_masks == 0] == 0.0)
            ),
            'shape_y': list(l_y.shape),
            'y_classes': [int(c) for c in np.unique(l_y)],
            'total_flows': len(l_y),
            'vpn_flows': int(np.sum(l_y == 1)),
            'nonvpn_flows': int(np.sum(l_y == 0)),
            'flow_id_traceable': bool(len(l_flows) == len(l_y) and all(isinstance(f, str) for f in l_flows)),
            'capture_id_traceable': bool(len(l_caps) == len(l_y) and all(isinstance(c, str) for c in l_caps))
        }
        validation_checks[s] = val_check

    # Compute overall statistics
    total_packets = sum(r['total_packets'] for r in pilot_audit_records)
    accepted_packets = sum(r['accepted_packets'] for r in pilot_audit_records)
    rejected_packets = sum(r['rejected_packets'] for r in pilot_audit_records)
    total_flows = sum(r['flows_generated'] for r in pilot_audit_records)

    # Runtime extrapolation to full dataset
    # Dataset total bytes: 25.78 GB = 27,680,683,212 bytes
    dataset_manifest_path = os.path.join(manifest_dir, "dataset_manifest.json")
    with open(dataset_manifest_path, 'r') as f:
        dmanifest = json.load(f)
    full_dataset_bytes = dmanifest['total_bytes']

    bytes_per_sec = total_bytes_processed / total_duration if total_duration > 0 else 1.0
    est_full_runtime_sec = full_dataset_bytes / bytes_per_sec
    est_full_runtime_min = est_full_runtime_sec / 60.0

    pilot_summary = {
        'files_selected_count': len(selected_files),
        'files_processed_count': sum(1 for r in pilot_audit_records if r['error'] is None),
        'files_failed_count': sum(1 for r in pilot_audit_records if r['error'] is not None),
        'total_mb_processed': round(total_bytes_processed / (1024 * 1024), 2),
        'total_duration_seconds': round(total_duration, 2),
        'throughput_mb_per_sec': round(total_bytes_processed / (1024 * 1024 * total_duration), 2),
        'est_full_dataset_runtime_minutes': round(est_full_runtime_min, 2),
        'total_packets_read': total_packets,
        'accepted_packets': accepted_packets,
        'rejected_packets': rejected_packets,
        'rejection_rate': round(rejected_packets / total_packets if total_packets > 0 else 0, 4),
        'total_flows_generated': total_flows,
        'per_file_records': pilot_audit_records,
        'validation_checks': validation_checks
    }

    summary_file = os.path.join(output_dir, "pilot_validation_summary.json")
    with open(summary_file, 'w') as f:
        json.dump(pilot_summary, f, indent=2)

    print(f"\nPilot run complete in {total_duration:.2f}s ({pilot_summary['throughput_mb_per_sec']} MB/s).")
    print(f"Summary saved to {summary_file}")
    return pilot_summary


if __name__ == '__main__':
    manifest_dir = "/Volumes/LEXAR/Explainability Drift/xdrift/data/manifests"
    raw_dir = "/Volumes/LEXAR/Explainability Drift/Dataset/ISCX VPN-NonVPN 2016 Dataset"
    output_dir = "/Volumes/LEXAR/Explainability Drift/xdrift/data/processed_pilot"
    run_pilot(manifest_dir, raw_dir, output_dir)
