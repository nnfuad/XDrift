# Table 3: Hardware, Latency, and Throughput Benchmarks (macOS ARM64 QNNPACK)

*Hardware: Apple Silicon Mac (M-series, 8 cores). Backend: CPU native execution via `torch.backends.quantized.engine = 'qnnpack'`. Measurements: 50 warmup runs, 500 timed repetitions.*

### Panel A: Storage & Model Footprint
| Model Architecture | Parameter Count | Disk Checkpoint Size | Storage Reduction | Execution Path |
| :--- | :---: | :---: | :---: | :---: |
| **FP32 Baseline** | 44,129 | 184.24 KB | 1.00× (Ref) | Standard FP32 Float Operations |
| **INT8-PTQ** | 44,129 | 51.77 KB | **3.56×** | Deployed `torch.qint8` Integer Operators |
| **INT8-QAT** | 44,129 | 51.77 KB | **3.56×** | Deployed `torch.qint8` Integer Operators |

---

### Panel B: Single-Flow Streaming Latency (Edge Scenario, Batch Size = 1)
*Characterizes immediate packet-arrival triage without buffering delay.*

| Model Architecture | Median Latency | Mean Latency | Latency Std Dev | Inter-Quartile Range (IQR) | 95th Percentile (p95) | 99th Percentile (p99) | Measured Throughput | Median Latency Speedup | Mean Throughput Speedup |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **FP32 Baseline** | **0.267 ms** | 0.291 ms | 0.074 ms | 0.042 ms | 0.405 ms | 0.580 ms | 3,438 flows/s | 1.00× (Ref) | 1.00× (Ref) |
| **INT8-PTQ** | 0.255 ms | 0.263 ms | 0.036 ms | 0.032 ms | 0.309 ms | 0.459 ms | 3,796 flows/s | **1.05× (Parity)** | **1.10×** |
| **INT8-QAT** | 0.242 ms | 0.250 ms | 0.023 ms | 0.012 ms | 0.281 ms | 0.372 ms | 4,005 flows/s | **1.10× (Faster)** | **1.16×** |

*Observation: At Batch Size = 1, quantization yields no speedup because PyTorch QNNPACK invocation, dynamic quantization of inputs, and scalar dequantization dominate computation.*

---

### Panel C: Batched Server Throughput (High-Volume Pipeline, Batch Size = 64)
*Characterizes offline audit, log ingestion, or buffered middlebox inspection.*

| Model Architecture | Median Batch Latency | Mean Batch Latency | Batch Latency Std Dev | 95th Percentile (p95) | Measured Throughput | Median Latency Speedup | Mean Throughput Speedup |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **FP32 Baseline** | 9.503 ms | 10.020 ms | 3.849 ms | 12.640 ms | 6,387 flows/s | 1.00× (Ref) | 1.00× (Ref) |
| **INT8-PTQ** | 0.764 ms | 0.839 ms | 0.233 ms | 1.228 ms | 76,264 flows/s | **12.44×** | **11.94×** |
| **INT8-QAT** | **0.755 ms** | **0.785 ms** | **0.127 ms** | **0.960 ms** | **81,552 flows/s** | **12.59×** | **12.77×** |

*Note: Measured throughput is calculated from mean batch latency (64 / mean_batch_latency_sec). Median latency speedup and mean throughput speedup differ slightly due to tail latency and OS scheduling variance. Observed throughput gains stem from PyTorch QNNPACK batched integer matrix multiplication on ARM64; microarchitectural instruction counters (e.g. NEON SIMD) were not directly profiled via hardware PMUs.*
