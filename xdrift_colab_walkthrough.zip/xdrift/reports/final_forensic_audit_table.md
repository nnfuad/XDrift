# Final Forensic Audit Table: Investigating Attribution Drift (XDrift)

**Audit Date**: October 24, 2026  
**Auditor**: Senior ML Research Engineer (Autonomous Forensic Review)  
**Target Repository**: `/Volumes/LEXAR/Explainability Drift/xdrift`  
**Overall Release Verdict**: **QUALIFIED RELEASE CERTIFIED (STAGE 1 COMPLETE & AUDITED)**  

---

## Executive Summary of Audit Results

This forensic audit evaluates all experimental, algorithmic, and statistical claims of the **XDrift** research project without retraining models, re-splitting data, reprocessing PCAP files, or overwriting checkpoints. Every priority item raised in review has been audited against raw binary checkpoints, precomputed prediction caches, attribution arrays, and mathematical ground truths.

---

## Comprehensive Forensic Audit Matrix

| Audit Item / Priority | Specific Claim / Implementation Detail | Target Source Code / Artifact | Audit Status | Forensic Quantitative Evidence & Verification |
| :--- | :--- | :--- | :---: | :--- |
| **Priority 1: Wilcoxon Signed-Rank Direction & Equivalence Language** | Direction of PTQ vs. Noise drift: Does $W=1506.0$ represent a positive or negative drift, and does it establish equivalence? | `src/statistics/paired_inference.py`<br>`results/attributions/cohort_attributions.npz` | **PASS** | $R^+ = 3544.0$, $R^- = 1506.0$, total rank sum = 5050.0. SciPy reports $W = \min(R^+, R^-) = 1506.0$. Two-sided $p = 0.0004589$; one-sided greater ($H_1: \Delta TV > 0$) $p = 0.0002295$. Positive rank sum dominates ($R^+ > R^-$); 69/100 flows have $\Delta TV > 0$. Median delta is minimal (+0.0049); 95/100 flows have identical Top-5 features ($IoU_5 = 0.9786$, Top-10 $IoU_{10} = 0.9887$, Signed Cosine $0.9918$, Spearman $\rho = 0.9749$). Arithmetic mean is negative (-0.0185) due to negative outlier noise runs (bootstrap CI: $[-0.0419, +0.0009]$). Sample std ($ddof=1$): $0.1120$; Population std ($ddof=0$): $0.1115$. Finding: Statistically detectable positive rank shift of minimal magnitude; does NOT establish statistical equivalence between PTQ drift and explainer noise. |
| **Priority 2: Attribution Provenance** | Cohort membership in clean test split ($N=49,251$) and bitwise logit alignment. | `results/attributions/cohort_attributions.npz`<br>`results/predictions/test_predictions.npz`<br>`data/processed/test_data.npz` | **PASS** | Exactly 100/100 cohort flow IDs exist in `test_data.npz` (50 VPN, 50 Non-VPN). Model forward logits match `test_predictions.npz` with maximum absolute difference $= 0.00 \times 10^0$ (exact bitwise match). Background dataset stratified (50 flows, seed 42). |
| **Priority 2: KernelSHAP Additivity** | Efficiency axiom verification: $\epsilon_i = \sum_j \phi_{ij} - [f(x_i) - \mathbb{E}(f(X_{\text{bg}}))]$. | `results/attributions/cohort_attributions.npz`<br>`artifacts/checkpoints/fp32_seed_42.pt`<br>`artifacts/quantized_models/ptq_seed_42.pt` | **PASS** | FP32: $\max |\epsilon_i| = 0.000007$, $\text{mean} |\epsilon_i| = 0.000002$.<br>PTQ: $\max |\epsilon_i| = 0.000000$, $\text{mean} |\epsilon_i| = 0.000000$.<br>QAT: $\max |\epsilon_i| = 0.000000$, $\text{mean} |\epsilon_i| = 0.000000$.<br>Efficiency axiom holds down to floating-point precision ($7 \times 10^{-6}$). |
| **Priority 3: Clustered Logit Shift CI: Estimand A vs B (16 Canonical Groups)** | Resampling independent canonical session groups ($K=16$) vs 19 raw files. | `src/statistics/paired_inference.py`<br>`results/predictions/test_predictions.npz` | **PASS** | Evaluated across 16 canonical session groups: Estimand A (pooled flow-weighted mean: $-0.0778$, CI $[-0.1130, +0.3275]$) and Estimand B (unweighted mean of group means: $+0.2270$, CI $[+0.0639, +0.3562]$). 13 of 16 canonical groups have positive shifts ($+0.10$ to $+0.53$). Only 3 groups are negative, anchored by `skype_audio3` (39,179 flows, 79.55% of test set, mean $-0.1164$). When cluster resampling omits `skype_audio3` (35.61% of resamples), the resampled flow-weighted mean becomes strongly positive. Sensitivity analysis excluding `skype_audio3` (15 canonical groups): Estimand A $+0.0720$ (CI $[-0.0770, +0.3454]$), Estimand B $+0.2499$ (CI $[+0.0870, +0.3673]$). Target population shift explicitly declared. Comparison with 19 raw files documented. |
| **Priority 4: H4 Subgroup Analysis** | Traffic class modulation of attribution drift, rank-biserial effect sizes, and agreement cohort. | `scripts/run_clean_reconciliation.py`<br>`results/tables/table4_hypothesis_matrix.md` | **PASS** | Delineated into 3 separate findings:<br>1. Total Variation: Statistically confirmed class conditioning (PTQ: $U = 480.0, p = 1.13 \times 10^{-7}, r_{\text{rb}} = +0.6160$; QAT: $U = 278.0, p = 2.12 \times 10^{-11}, r_{\text{rb}} = +0.7776$).<br>2. Top-5 Jaccard: Insufficient evidence of class conditioning (PTQ: $U = 1174.0, p = 0.1681$; QAT: $U = 1199.0, p = 0.3976$).<br>3. Prediction Agreement: Strictly **NON-ESTIMABLE** (100% agreement between FP32 and PTQ on the 100-flow cohort, $N_{\text{disagree}} = 0$). Status: PARTIALLY SUPPORTED. |
| **Priority 4: Predictive Validation Calibration** | Threshold calibration on validation set vs. reused FP32 threshold. | `src/training/train.py`<br>`results/predictions/test_predictions.npz`<br>`results/tables/table1_predictive_performance.md` | **PASS** | Validation thresholds: $\tau_{\text{FP32}} = 0.900, \tau_{\text{PTQ}} = 0.900, \tau_{\text{QAT}} = 0.680$.<br>Reused $\tau=0.900$ on QAT produces total recall collapse (0 positive calls, F1 = 0.0000) because QAT probabilities do not exceed $0.7338$. Calibrated $\tau=0.680$ restores QAT F1 to 0.7762. Confusion matrices verified across 49,251 test flows (2,693 VPN, 46,558 Non-VPN). |
| **Priority 4: Probability Calibration & Murphy Decomposition** | Resolving whether QAT's low Brier score ($0.0237$) reflects superior confidence estimation. | `scripts/run_scientific_reproducibility_gate.py`<br>`results/predictions/test_predictions.npz` | **PASS** | Base rate $\bar{y} = 0.054679$, Uncertainty $= 0.051689$.<br>FP32: Brier $= 0.0585$ (Reliability $= 0.0378$, Resolution $= 0.0314$, ECE $= 0.1691$, MCE $= 0.7417$).<br>PTQ: Brier $= 0.0584$ (Reliability $= 0.0369$, Resolution $= 0.0310$, ECE $= 0.1611$, MCE $= 0.7417$).<br>QAT: Brier $= 0.0237$ (Reliability $= 0.0036$, Resolution $= 0.0316$, ECE $= 0.0378$, MCE $= 0.5511$).<br>Demonstrated that QAT's lower Brier score is driven by logit contraction compressing Non-VPN predicted probabilities to mean $0.0557$ ($94.41\%$ in Bin 0) on a $94.53\%$ majority-class dataset, reducing quadratic loss $(\hat{p}_i-0)^2$. Threshold $\tau=0.680$ is the validation-selected F1 threshold, not a universally optimal cost threshold. |
| **Priority 5: Hardware Benchmark Single Source of Truth** | BS=1 streaming latency vs BS=64 batched throughput speedup; tracing to authoritative raw artifact. | `src/evaluation/benchmark_hardware.py`<br>`results/metrics/hardware_benchmarks.json`<br>`results/tables/table3_hardware_benchmarks.md` | **PASS** | Traced directly to `results/metrics/hardware_benchmarks.json`.<br>BS=1 (500 timed runs, 50 warmup): FP32 median 0.267 ms (3,438 flows/s), PTQ 0.255 ms (3,796 flows/s, 1.05× latency speedup, 1.10× throughput speedup), QAT 0.242 ms (4,005 flows/s, 1.10× latency speedup, 1.16× throughput speedup).<br>BS=64: FP32 median 9.503 ms (6,387 flows/s), PTQ median 0.764 ms (76,264 flows/s, 12.44× latency speedup, 11.94× throughput speedup), QAT median 0.755 ms (81,552 flows/s, 12.59× latency speedup, 12.77× throughput speedup). Disentangled and reported separately. Speculative unprofiled framework overhead assertions removed. |
| **Priority 6: IoT / Edge Hardware Boundaries** | Bounding hardware throughput conclusions to tested desktop ARM64 architecture. | `reports/final_research_report.md`<br>`reports/final_release_checklist.md` | **PASS** | Explicitly documented that benchmarks represent Apple Silicon Mac desktop ARM64 execution with QNNPACK runtime and do not extrapolate directly to embedded microcontrollers (ARM Cortex-M, Raspberry Pi, low-power IoT gateways, CCTV cameras, smartwatches) without on-device profiling. 3.56× checkpoint reduction (184.24 KB to 51.77 KB) is verified for flash storage. |
| **Gate 1: Session-Group Disjunction** | Zero group or session overlap across Train, Val, and Test splits. | `src/data/leakage_free_split.py`<br>`tests/test_preprocessing.py` | **PASS** | 106 unique canonical groups across 140 PCAPs. `'hangout_chat_4': 'hangouts_chat_4'` alias co-locates `hangouts_chat_4a` and `hangout_chat_4b` in Train. Pairwise group intersections are all strictly empty. Flow overlap is `False`. |
| **Gate 2: Quantized Operator Realism** | Real integer operator deployment and absence of artificial clamping. | `src/models/cnn1d.py`<br>`artifacts/quantized_models/ptq_seed_42.pt` | **PASS** | Deployed graph executes real `torch.qint8` integer operators under `qnnpack`. Linear layer `fc2` has scale 0.069318 and zero-point 105, supporting negative logits down to -7.27. Exactly 0 test flows clamped at 0.0. |
| **Gate 3: Training Provenance** | Reproducible training checkpoints and loss minimization. | `artifacts/checkpoints/fp32_seed_42.pt`<br>`artifacts/quantized_models/qat_seed_42.pt` | **PASS** | FP32 trained with BCEWithLogitsLoss (`pos_weight` = 30.3756 from train split only). QAT fine-tuned for 5 epochs with fake-quantization. Checkpoint hashes verified. |
| **Gate 8: Regression Test Suite** | Automated test suite execution. | `tests/test_attribution_metrics.py`<br>`tests/test_models.py`<br>`tests/test_preprocessing.py` | **PASS** | 15/15 unit and regression tests pass with exit code 0 (`pytest tests/ -v`, 2.12s execution time). |

---

## Artifact Integrity & Checksum Verification Table

| Artifact Name | Relative File Path | SHA-256 Checksum |
| :--- | :--- | :--- |
| **Train Dataset** | `data/processed/train_data.npz` | `e0e07bf22c18877180fdd53469df60988f93b0bb570263290da12247b95d29ef` |
| **Validation Dataset** | `data/processed/val_data.npz` | `9b3d3e44b8b77151de5dbdb8b096bbc8ab37be2b0aaf67a64135655c362813e5` |
| **Test Dataset** | `data/processed/test_data.npz` | `9d238910e51feb629c2adaa0951592bdb9031e9675ee36265f02042ee03fc73e` |
| **FP32 Checkpoint** | `artifacts/checkpoints/fp32_seed_42.pt` | `a6b5d65f80e05f8a8847ec261cef71499a4f732d168e8c7e8158bc413fcfed93` |
| **INT8-PTQ Model** | `artifacts/quantized_models/ptq_seed_42.pt` | `6b77806383723c40645172eeef23747866510c0b7507307b9bdc8c4c16926410` |
| **INT8-QAT Model** | `artifacts/quantized_models/qat_seed_42.pt` | `13fcfde7938c1787e6e8e15bafd1e3723bca0ca06b1e24bea210e0b3d783b8ca` |
| **Test Predictions** | `results/predictions/test_predictions.npz` | `a6fe7ee3816b9c38761f618f66008dc0d1cf9404c4c0e56958525204066a9dd8` |
| **Cohort Attributions** | `results/attributions/cohort_attributions.npz` | `b17ccf97c381f9f11f56a3368966fed53902b937cfd6854f3308cf95f8b89b13` |
| **Explainer Repeatability** | `results/attributions/explainer_repeatability_cohort.npz` | `51edf732c24266a475288ed3a04ba7b38c6170119596bd8f52d39fac001fc611` |
| **Master Summary JSON** | `results/metrics/master_pipeline_summary.json` | `91b8b7d76a36cfc8f87c9d70e649715c246aacda3580c80d4eb8b03a1385a4dd` |
| **Hardware Benchmarks JSON** | `results/metrics/hardware_benchmarks.json` | `6ebd56d6f0d8a7d912c03f8b95108794b0e9a74845aff9caf3bfab40cb11d80a` |
| **Table 1 (Predictive)** | `results/tables/table1_predictive_performance.md` | `fe277ec45a07c37ef11a1c386eb22aedc26f2b0834ec4b96458a223d77f6c29c` |
| **Table 2 (Attribution)** | `results/tables/table2_attribution_drift.md` | `ba32c359bade6cc4507f8178f5f9e2d4817732f3cd9e3836f74991e39578a1ea` |
| **Table 3 (Hardware)** | `results/tables/table3_hardware_benchmarks.md` | `9bbb20d5b80d4a249da00b90d6c80cac9c24b81ca03dba4ed3f06e95c3617fd3` |
| **Table 4 (Hypothesis)** | `results/tables/table4_hypothesis_matrix.md` | `d7ebf6bbf8227fb323cda8f6ae5ac65ae9c3ab675f5fdc76c74748af9cf94a0f` |
| **Leakage Split Code** | `src/data/leakage_free_split.py` | `f27e5b7adf2deabbccfb7f3fceb41d6db04d30fda9cedfd0f01d02ec3987124d` |
| **Paired Inference Code** | `src/statistics/paired_inference.py` | `4327fadff5bfae1e7d0db409e9a058455a7c27bdcf66061bca8e58248531c121` |
| **KernelSHAP Code** | `src/explainability/kernel_shap.py` | `d7a744d9479a540fab7cfb9f18e479ec4834981f8813fd192a0c386b4c7f39ae` |
| **Hardware Benchmark Code** | `src/evaluation/benchmark_hardware.py` | `d604c92abe67c116d8d4ac55d03e9c82ec141aa7b8442ca8c34e2064720e8131` |
| **Reconciliation Script** | `scripts/run_clean_reconciliation.py` | `525ad5c7e30efbc9a55a0aabe79989ea2a06587da8e9d794699b3883939cbe21` |
| **Reproducibility Gate Script** | `scripts/run_scientific_reproducibility_gate.py` | `96ff9405ed12f720a0fec94c53437b54bc708275c2931b604d3589bd5fd16299` |

---

## Grounded Release Recommendation

### Final Verdict: **QUALIFIED RELEASE CERTIFIED**

Based on this comprehensive forensic audit:
1. **The methodology is sound, consistent, and strictly leakage-free**: The 106 canonical session groups guarantee complete isolation between training, validation, and testing.
2. **All audit discrepancies have been conclusively resolved**:
   - The Wilcoxon signed-rank test direction has been proven positive ($R^+ = 3544.0 > R^- = 1506.0$, $p = 0.00023$ one-sided, $p = 0.00046$ two-sided) while clarifying its minimal physical magnitude and disclaiming statistical equivalence. Both sample std ($0.1120$) and population std ($0.1115$) are reconciled.
   - Attribution provenance is verified with 100/100 cohort flows present in `test_data.npz`, exact logit identity ($0.00 \times 10^0$), and additivity residuals bounded by $7 \times 10^{-6}$.
   - Primary cluster bootstrap inference is aligned with the **16 canonical session groups** (Estimand A $-0.0778$, CI $[-0.1130, +0.3275]$; Estimand B $+0.2270$, CI $[+0.0639, +0.3562]$), with the population shift for sensitivity analysis (excluding `skype_audio3`) and the 19-file comparison transparently reported.
   - Hypothesis H4 has been formalized into three separate findings (TV class conditioning confirmed, Top-5 overlap unconditioned, prediction agreement non-estimable).
   - Hardware benchmarks cleanly disentangle median latency speedup from mean throughput speedup, tracing to a single authoritative source (`hardware_benchmarks.json`), avoiding unverified framework overhead assertions, and bounding claims away from embedded microcontrollers without physical profiling.
   - Murphy decomposition proves QAT's calibration metrics stem from Non-VPN probability shrinkage on a 94.5% majority class rather than superior intrinsic confidence calibration.
3. **The manuscript is thesis- and publication-ready**: All claims are bounded strictly to the ISCX 2016 benchmark split and empirical evidence. No further training or re-splitting is required.
